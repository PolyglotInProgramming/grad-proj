<?php 
session_start();
include('connection.php');
/*

if (isset($_POST['reassign'])) {

$driver_id=$_POST['driver_id'];
$vehicleid=$_POST['result'];


   
$update = "UPDATE driver SET vehicleid='$vehicleid' WHERE id='$driver_id'";
mysqli_query($conn,$update);
if($udate_run){
$_SESSION['reassign'] = "Vehicle reassigned successfully";

header("Location:Reassign_vehicle.php");      
}else{

  $_SESSION['reassign'] = "something went wrong";
  header("Location:Reassign_vehicle.php");      
}}

?>*/
if (isset($_POST['reassign'])) {

$driver_id= $_POST['driverid'];
$vehicleid=$_POST['vehicleid'];

  //echo $driver_id;
  //echo $vehicleid;
/*
$select = "SELECT * FROM driver WHERE email = '$email'";//AND id ='$id' ?
$result = mysqli_query($conn,$select);
*/

//لازم يحدث الشاحنه ولا بيقول ايرور      
$update = "UPDATE driver SET  vehicleid='$vehicleid' WHERE id='$driver_id'";
$Q = mysqli_query($conn,$update);
if($Q){
  $_SESSION['reassignStatus'] = "Vehicle reassigned successfully";
header("Location:assigned_vehicles.php");//<----      <----
  } else {
    $_SESSION['reassignStatus'] = "sql error";
header("Location:assigned_vehicles.php");//<----      <----
  }

}
?>
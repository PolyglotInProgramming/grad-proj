<?php
  session_start();
  include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>View Reservations</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!--for icons-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="btncolor.js"></script>
  <style>
    .navbar-nav>span {
      padding-left: 30px;
      padding-right: 0px;
    }

    .size {
      font-size: 100%;
      text-align: center;

    }

    i {
      color: #4c548c;
    }

    i:hover {
      color: #f1c232;
    }

    .card {
      margin-bottom: 20px;
    }

    .bttn {
      width: 100%;

    
      color: white;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 10px;
      cursor: pointer;
    }

    .content-table {
      border-collapse: collapse;
      margin: 25px 0;
      font-size: 0.9em;
      min-width: 400px;
      border-radius: 5px 5px 0 0;
      overflow: hidden;
    }

    .content-table thead tr {
      background-color: #4c548c;
      color: #f1c232;
      text-align: left;
      font-family: sans-serif;
      font-weight: bold;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    }

    .content-table td {
      padding: 12px 15px;

    }

    .content-table tbody tr:nth-of-type(odd) {
      background-color: #D1E3FA;
    }

    .modal-header {
  background-color: #96A5D4;
  color: #ffffff;
}

.modal-header {
  background-color: #96A5D4;
  color: #ffffff;
}
  </style>
</head>

<body>
  <div class="container-fluid">
    <div style="background-color:#96A5D4;color:#ffffff;" class="row">
      <div class="col-1">
      </div>
      <div class="col">
        <br>
        <?php echo '<h5> Welcome <span class="text-warning">' . $_SESSION["fname"] .' '. $_SESSION["lname"]. ' </span>!</h5>';?>
      </div>
    </div>
  </div>

  <div style="background-color:#4c548c;" class="row">
    <div class="col-1"></div>

    <div class="col">

    <nav style="background-color:#4c548c;" class="navbar navbar-expand-sm navbar-light size">
                    <a href="مها#"><img class="d-inline-block align-top" src="logo.png" width="60" height="60" /></a>
                    <div class="collapse.navbar-collapse" id="navbarNav" >
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a href="Dashboard.php" class="nav-link " style="color:#d1d5e4">
                                    DASHBOARD
                                </a>
                            </li>
                           
                            <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle" style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                  Manage Vehicles
                                </a>
                                <ul class="dropdown-menu "  >
                                  <li><a class="dropdown-item" style="color:#4c548c;" href="add_vehicle.php">Add Vehicle</a></li> 
                                  <li><a class="dropdown-item "  style="color:#4c548c;" href="vehicles_table.php">View Vehicles</a></li> 
                                  <li><a class="dropdown-item"  style="color:#4c548c;" href=" assigned_vehicles.php ">View assigned Vehicles</a></li> 
                                </ul>
                              </li>

                              <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle " style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Manage Drivers
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="add_driver.php">Add Driver</a></li> 
                                    <li><a class="dropdown-item"  style="color:#4c548c;" href="admin_view_driver.php">View Drivers</a></li> 
                                </ul>
                              </li>



                              <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle   text-warning" style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Manage Reservations
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="add_schedule_findD.php">Organize Schedule</a></li> 
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="organize_schedule.php">Created Schedules</a></li> 
                                    <li><a class="dropdown-item bg-warning "  style="color:#4c548c;" href="admin_view_reservations.php">View Reservations</a></li> 
                                </ul>
                              </li>  
                                                            

                              <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle" style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Customers
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="admin_view_customer.php">View Customers</a></li> 
                                    <li><a class="dropdown-item " style="color:#4c548c;"  href="admin_view_feedback.php">View Feedbacks</a></li>                                </ul>
                              </li> 

                            <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle " style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Announcements
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="admin_send_annunc.php	">Send Announcement</a></li> 
                                    <li><a class="dropdown-item"  style="color:#4c548c;" href="admin_annuncment.php">Sent Announcements</a></li> 
                                </ul>
                              </li> 


                            <span class="navbar-nav">
                                <button type="button" style="font-size: 100%;" class="btn btn-warning"> <a
                                        style="font-size: 100%;" class="btn p-0 " href="logout.php">Log Out</a>
                                </button>
                            </span>
                        </ul>
                    </div>
                </nav>

    </div>
  </div>
  <!----------------------->
  <br>
  <h4 style="color:#4c548c;">
    <center>Reservations</center>
  </h4>

<div class="container"> 
  <div class="table-responsive"> <table class="table table-hover">

    <table class="table table-striped content-table" style="width:100%">
      <thead>
        <tr>
          <th class="text-center"> ID</th>
          <th class="text-center">Date</th>
          <th class="text-left">Pick up time</th>
          <th class="text-left">Drop off time</th>
          <th class="text-left">Pick up Location</th>
          <th class="text-left">Drop off Location</th>

<th class="text-center">Details</th>
<!--          
          <th class="text-left">Driver id</th>
          <th class="text-left">Driver Name</th>
          <th class="text-left">Driver Phone</th>
          <th class="text-center">Driver</th>
          <th class="text-left">Customer id</th>
          <th class="text-left">Customer Name</th>
          <th class="text-left">Customer Phone</th>
          <th class="text-left">Vehicle ID</th>
          <th class="text-left">Vehicle Name </th>
-->

          <th class="text-center">price</th>
          <th class="text-center">Status</th>

        </tr>
      </thead>
      <tbody>
        
        <?php
$conn = mysqli_connect("localhost","root","","pickme");
if($conn-> connect_error){
die("Connection failed:".$conn-> connect_error);
}
$sql ="SELECT *  from reservation_view WHERE NOT status='available'";
$result = $conn-> query($sql);

if ($result-> num_rows > 0){
    while ($row = $result-> fetch_assoc()){
echo "<tr><td>".$row["RID"]."</td><td>".$row["date"]
."</td><td>".$row["pickuptime"]."</td><td>".$row["dropofftime"]
."</td><td>".$row["pickuplocation"]."</td><td>".$row["dropofflocation"]
."</td><td>";
?>

<div class="container mt-1">
<center><button type="button" name="Details" class="btn btn-warning py-0 px-2" data-bs-toggle="modal" data-bs-target ="#myModal">Details</button></center> 

<div class="modal" id="myModal">
<div class="modal-dialog" >
<div class="modal-content">


<div class="modal-header bg-warning">
  <h5 class="modal-title">Details</h5>
  <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body">
<center>
<div class="row">
  <div class="col">
<div class="mb-3">
<h6> Customer id</h6>
<p><?php echo $row["Cid"]; ?></p>
<h6> Customer name</h6>
<p><?php echo $row["customernamef"].' '.$row["customernamel"]; ?></p>
<h6> Customer phone</h6>
<p><?php echo $row["customerno"]; ?></p>
</div>
  </div>
  <div class="col">
<div class="mb-3">
<h6> Driver id</h6>
<p><?php echo $row["Did"]; ?></p>
<h6> Driver name</h6>
<p><?php echo $row["drivernamef"].' '.$row["drivernamel"]; ?></p>
<h6> Driver phone</h6>
<p><?php echo $row["driverno"]; ?></p>
</div>
  </div>
  <div class="col">
<div class="mb-3">
<h6> Vehicle id</h6>
<p><?php echo $row["vid"]; ?></p>
<h6>  Vehicle name</h6>
<p><?php echo $row["vehiclename"]; ?></p>
</div>
  </div>
</div>

</center>
</div>

</div>

</div>

</div>
</div>

<?php
echo "</td><td>".$row["price"]."</td><td>";
?>

<?php 
 if( $row["status"]=='available'){
   echo "<span class='bttn badge p-1 bg-secondary center'>Available</span></tb>";
   echo "</td></tr>"; 
 

  
 }elseif( $row["status"]=='pending'){
  echo "<span class='bttn badge p-1 bg-warning center'>Pending</span></tb>";
  echo "</td></tr>"; 




}elseif($row["status"]=='picked up'){
  echo " <span class='bttn badge p-1 bg-success'>picked up</span></td>";
  echo "</td></tr>"; 
 

 
}elseif($row["status"]=='canceled'){
  echo " <span class='bttn badge p-1 bg-danger right'>canceled</span></td>";
  echo "</td></tr>"; 
 
}elseif($row["status"]=='paid'){
  echo " <span class='bttn badge p-1 bg-info right'>paid</span></td>";
  echo "</td></tr>"; 
 
 
}else{
  echo " <span class='bttn badge p-1 bg-primary right'>Dropped off</span></td>";
}echo "</td></tr>"; 
 }
  echo "</table>"; }
$conn-> close();
    
?>
<?php
/*
<form action="driverinfo.php" method="POST">
  <button type="submit" class="btn btn-warning p-1" name="editDriver" value="<?php echo $row["id"]; ?>"><i class=" hover fa fa-edit fa-2x " data-feather="edit"></i>
</button>
</form>

*/
/*
"</td></tr>";
    }
   
    echo "</table>";
}else{
    echo "0 result";
}
$conn-> close();
*/
?>
       
   </table> 
     </table> 
  </div>
</div>

</body>

</html>




    </table>


</body>

</html>
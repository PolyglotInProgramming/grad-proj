<?php
session_start();
include('connection.php');

echo "ccc";
//\\// reserve \\//\\
if (isset($_POST['reserve'])) {
  //$cid = 4; // customer id 
    $cid = $_SESSION['id']; // customer id 
    $Rid = $_POST['Rid'];// reservation id 
    
  $pickuplocation = $_POST['pickuplocation'];
    $dropofflocation = $_POST['dropofflocation'];
    
    
        $reserve = "UPDATE reservation SET customerid = '$cid', pickuplocation ='$pickuplocation' , dropofflocation ='$dropofflocation' , status = 'pending' WHERE Rid = '$Rid'";
        mysqli_query($conn,$reserve);
        $_SESSION['reserveStatus'] = "Reserved successfully";

        //$_SESSION['reserveStatus'] = "Driver registered sucessfully.";
        header("Location:customer/customer_reservation.php");
        }
    
    

        





    //\\// find
/*
if (isset($_POST['find'])) {
$category = $_POST['category'];
$city = $_POST['city'];
$triptype = $_POST['triptype'];
$date = $_POST['date'];

// check if date in the future or not
$todydate = date('Y-m-d');
// convert to strotime
$str_date = strtotime($date); 
$str_todydate = strtotime($todydate); 
// compare
if($str_date < $str_todydate){
  $_SESSION['searchDate'] ="The date cannot be in the past";
  //header("Passengers reservation form.php");

}else{

    $_SESSION['reserveStatus'] = "????? reserved successfully";
    $find = "SELECT * FROM `created_schedules2` WHERE `date`= $date, `status`='available', `city`= $city , `category`= $category, `triptype`= $triptype ";
    mysqli_query($conn,$find);
    //$_SESSION['regesterStatus'] = "Driver registered sucessfully.";
    header("Location:?????.php");
    }

}
*/
?>
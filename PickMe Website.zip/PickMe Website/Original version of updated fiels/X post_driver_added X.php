<?php
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
// adding driver
  session_start();
  include 'connection.php';
  
  if (isset($_POST['driver'])) {
    $fname =$_POST['fname'];
    $lname =$_POST['lname'];
    $email =$_POST['email'];
    $password =$_POST['password'];
    $phonenum =$_POST['phonenum'];
    if(isset($_POST['city'])){$city = $_POST['city'];}
    $trip =$_POST['trip'];
    $lictype =$_POST['lictype'];
    $licexp =$_POST['licexp'];

   $select = "SELECT * FROM driver WHERE email = '$email'";
    $result = mysqli_query($conn,$select);

    if (mysqli_num_rows($result) > 0) {
    $_SESSION['regesterStatus'] = "Email already registered.";
    header("Location:add_driver.php");
   } else {
    $registr = "INSERT INTO customer (fname,lname,email, password, phonenum,city, trip, lictype, licexp ) VALUES ('$fname','$lname','$email','$password','$phoneno','$city','$trip','$lictype','$licexp')";
    //UPDATE table_name SET column1 = value1, column2 = value2, ... WHERE condition;
    mysqli_query($conn,$registr);
    $_SESSION['regesterStatus'] = "Driver registered sucessfully.";
    header("Location:add_driver.php");

  }
  }





/*else { 
//realy reserved
$_SESSION["editDriverStatus"] = "Cannot delete Schedule under progrsess";
header("Location:organize_schedule.php");
}*/


?>


<?php
/* $fname =$_POST['fname'];
$lname =$_POST['lname'];
$email =$_POST['email'];
$password =$_POST['password'];
$phonenum =$_POST['phonenum'];
if(isset($_POST['city'])){$city = $_POST['city'];}
$trip =$_POST['trip'];
$lictype =$_POST['lictype'];
$licexp =$_POST['licexp'];


$conn =new mysqli('localhost','root','','pickme');
if($conn->connect_error){

    die('Connection failed :' .$conn->connect_errer);

}else{

$stmt = $conn->prepare("insert into registration(fname ,lname ,email ,password ,phonenum ,city ,trip ,lictype ,licexp)
 values(?, ?, ?, ?, ?, ?, ?, ?, ?)");
 $stmt->bind_param("ssssissss",$fname,$lname,$email,$password,$phonenum,$city,$trip,$lictype,$licexp);
$stmt->execute();
$stmt->close();
$conn->close();
}


*/?>

<?php
session_start();
include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
  
<div class="container-fluid ">
<div class="row">
        <div class="col-sm-12 p-3 bg-light text-white">
            <br>
        </div>
</div>

  <div class="row">
    <div class="col-sm-4 p-3 bg-light text-white"></div>
<!--  <div  class="col-sm-4 p-3 bg-warning text-white ">-->  

    <div style ="background-color: #94a4d4;" class="col-sm-4 p-3  text-white ">
        <center><img src="logo.png"  style="width:20%;" alt="Website Logo"></center>
    <h2  class="text-warning"><center> Admin Login Panel </center> </h2>
   <br>
        <center>
        <form action="a_login.php" method="POST">
            <label ><b>Enter your email:</b></label>
            <br>
            <input type="email" placeholder="email" maxlength="50" name="email" required>
            <br><br>
            <label ><b>Enter your password:</b></label>
            <br>
           <input type="password"  placeholder="password" maxlength="8" name="password" required>
           <br><br>
           <input type="submit" class="btn btn-light" name="login" value="Log in"></input>

        </form>

        <?php
if (isset($_SESSION['loginStatus'] )){
          echo '<center>';
          echo '<div class="text-danger">'. $_SESSION['loginStatus'] .'</div>';
          echo '</center>';
          unset($_SESSION['loginStatus']);
}
?>

        <a class="btn"  href="لسى ما سوبناه">Forgot password</a>
        <br>
        <a class="btn"  href="../Home.php">Home</a>

        </center>
    </div>

    <?php
    /*
      if (isset($_POST['login'])) {
        $email = $_POST['email'];
        $password = $_POST['password'];
        $select = "SELECT * FROM admin WHERE email = '$email' AND password = '$password'";
        $result = mysqli_query($conn,$select);
        $row = mysqli_fetch_array($result);

        if (is_array($row)) {
          $_SESSION["email"] = $row['email'];
          $_SESSION["password"] = $row['password'];
          $_SESSION["fname"] = $row['fname'];
          $_SESSION["lname"] = $row['lname'];

        } else {
          echo '<script type="text/javascript>'; 
          echo 'alter("Invalid email or password!");';
          echo 'window.location.href = "admin_login.php"';
          echo '</script>';
        }
        }

        if(isset($_SESSION["email"])){
          header("Location: Dashboard.html");// echo 'Welcome' . " " . $_SESSION["firstname"] . " " . $_SESSION["lastname"]
        }
        */
      ?>


    <div class="col-sm-4 p-3 bg-light text-white"></div>

  </div>
<div class="row">
    <div class="col-sm-12 p-3 bg-light text-white">
        <br><br>
    </div>

</div>

</body>
</html>

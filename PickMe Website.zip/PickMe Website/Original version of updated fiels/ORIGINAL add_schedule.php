<?php
  session_start();
  include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Add Schedule</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!--for icons-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    .navbar-nav>span {
      padding-left: 40px;
      padding-right: 0px;
    }

    .size {
      font-size: 80%;
      text-align: center;

    }

    .card {
      margin-bottom: 20px;
    }

    input[type=text],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=email],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=password],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=number],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=date],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=submit] {
      width: 100%;
      background-color: #4c548c;
      color: #f1c232;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    input[type=reset] {
      width: 100%;
      background-color: #f1c232;
      color: #4c548c;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }


    div.container {
      border-radius: 5px;
      background-color: #f2f2f2;
      padding: 20px;
    }
  </style>
</head>

<body>
  <div class="container-fluid">
    <div style="background-color:#96A5D4;color:#ffffff;" class="row">
      <div class="col-1">
      </div>
      <div class="col">
        <br>
        <?php echo '<h5> Welcome <span class="text-warning">' . $_SESSION["fname"] .' '. $_SESSION["lname"]. ' </span>!</h5>';?>
      </div>
    </div>
  </div>

  <div style="background-color:#4c548c;" class="row">
    <div class="col-1"></div>

    <div class="col">
    <nav style="background-color:#4c548c;" class="navbar navbar-expand-sm navbar-light size">
                    <a href="مها#"><img class="d-inline-block align-top" src="logo.png" width="60" height="60" /></a>
                    <div class="collapse.navbar-collapse" id="navbarNav" >
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a href="Dashboard.php" class="nav-link " style="color:#d1d5e4">
                                    DASHBOARD
                                </a>
                            </li>
                           
                            <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle" style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                  Manage Vehicles
                                </a>
                                <ul class="dropdown-menu "  >
                                  <li><a class="dropdown-item" style="color:#4c548c;" href="add_vehicle.php">Add Vehicle</a></li> 
                                  <li><a class="dropdown-item "  style="color:#4c548c;" href="vehicles_table.php">View Vehicles</a></li> 
                                  <li><a class="dropdown-item"  style="color:#4c548c;" href=" assigned_vehicles.php ">View assigned Vehicles</a></li> 
                                </ul>
                              </li>

                              <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle " style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Manage Drivers
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="add_driver.php">Add Driver</a></li> 
                                    <li><a class="dropdown-item"  style="color:#4c548c;" href="admin_view_driver.php">View Drivers</a></li> 
                                </ul>
                              </li>



                              <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle   text-warning" style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Manage Reservations
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                <li><a class="dropdown-item bg-warning " style="color:#4c548c;" href="add_schedule.php">Organize Schedule</a></li> 
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="organize_schedule.php">Created Schedules</a></li> 
                                    <li><a class="dropdown-item "  style="color:#4c548c;" href="admin_view_reservations.php">View Reservations</a></li> 
                                </ul>
                              </li>  
                                                            

                              <li class="nav-item">
                                <a href="admin_view_customer.php" class="nav-link" style="color:#d1d5e4">View
                                    Customers</a>
                            </li>

                            <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle " style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Announcements
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="admin_send_annunc.php	">Send Announcement</a></li> 
                                    <li><a class="dropdown-item"  style="color:#4c548c;" href="admin_annuncment.php">Sent Announcements</a></li> 
                                </ul>
                              </li> 


                            <span class="navbar-nav">
                                <button type="button" style="font-size: 100%;" class="btn btn-warning"> <a
                                        style="font-size: 100%;" class="btn p-0 " href="logout.php">Log Out</a>
                                </button>
                            </span>
                        </ul>
                    </div>
                </nav>
    </div>
  </div>
  <br>
  <h3 class="text-center" style="color:#4c548c;">Add New Reservation Schedule</h3>
  <div class="container">
    <form style="color:#4c548c;" action="/action_page.php">
      <label style="color:#4c548c;" for="vname">Reservation ID</label>
      <input type="text" id="vname" name="virstname" maxlength="6" placeholder="Ex. 000000" required>

      <label style="color:#4c548c;" for="Date">Select Date</label>
      <input type="date" id="Date" name="aate" required>
      <label style="color:#4c548c;" for="vname">Set pick up time</label>
      <input type="time" id="vname" name="virstname" required>
      <br><br>
      <label style="color:#4c548c;" for="vname">Set drop off time</label>
      <input type="time" id="vname" name="virstname" required>


      <hr>


      <label style="color:#4c548c;" for="City">City</label>
      <span class=" text-warning">*</span><br>
      <select id="City" name="city">
      <option value=" ">--Select--</option>
        <option value="Riyadh">Riyadh</option>
        <option value="Dammam">Dammam</option>
        <option value="Jeddah">Jeddah</option>
        <option value="Medina">Medina</option>
        <option value="Mecca">Mecca</option>
        <option value="Taif">Taif</option>
        <option value="Al-Ahsa">Al-Ahsa</option>
        <option value="Hafar Al Batin">Hafar Al Batin</option>
        <option value="Hail">Hail</option>
        <option value="Tabuk">Tabuk</option>
        <option value="Arar">Arar</option>
        <option value="Jazan">Jazan</option>
        <option value="Najran">Najran</option>
        <option value="Al Bahah">Al Bahah</option>
        <option value="Al-Qasim">Al-Qasim</option>
        <option value="Jouf">Jouf</option>
        <option value="Aseer">Aseer</option>

      </select>


      <br>

      <label style="color:#4c548c;" for="triptype">Trip Type</label>
      <span class=" text-warning">*</span><br>

      <select id="Trip" name="triptype">
      <option value=" ">--Select--</option>
        <option value="Long">Long</option>
        <option value="Short">Short</option>

      </select>
<!--
      <label style="color:#4c548c;" for="TripType">Trip Type </label>
      <span class=" text-warning">*</span>
      <input type="radio" id="long" name="triptype" value="Long">
      <label style="color:#4c548c;" for="long">Long</label>
      <input type="radio" id="short" name="triptype" value="Short">
      <label style="color:#4c548c;" for="short">Short</label>
      <br>
-->


      <br>
      <label style="color:#4c548c;" for="Category">Category</label>
      <span class=" text-warning">*</span><br>
      <select id="Category" name="Category" required>
      <option value=" ">--Select--</option>
        <option value="Delivery vans"> Delivery vans</option>
        <option value="Standard">Standard</option>
        <option value="express"> express</option>
        <option value="First class">First class</option>
      </select>
      <hr>
      <span class=" text-warning"> *The above fields are required to suggest suitable drivers</span>
      <br>
      <label style="color:#4c548c;" for="driver">Assign driver</label>
      <?php
$con = mysqli_connect('localhost','root','','pickme');


    $s=mysqli_query($con,"SELECT id,fname FROM driver");?>
      <select style="color:gray;" id="driver" name="driver_id" required>
     <option  value="">id driver</option>
       <?php

       while($r =mysqli_fetch_array($s))
      { ?>
       <option value="<?php echo $r['id'];?>"><?php echo $r['id']." ".$r['fname'];?></option> 
       <?php    
      }

      ?>
      </select>
      <hr>

      <label for="Price">Price</label>
      <input type="number" id="Price" name="price">


      <input type="submit" value="Add Schedule">
      <input type="reset" value="Reset">
    </form>
  </div>


</body>

</html>
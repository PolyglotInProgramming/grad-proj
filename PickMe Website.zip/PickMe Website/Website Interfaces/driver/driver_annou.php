<?php
  session_start();
  include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Announcements</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!--for icons-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>


  <style>
    .navbar-nav>span {
      padding-left: 400px;
      padding-right: 0px;
    }

    .size {
      font-size: 100%;
      text-align: center;

    }

    i {
      color: #4c548c;
    }

    i:hover {
      color: #f1c232;
    }

    .card {
      margin-bottom: 20px;
    }

    .bttn {
      width: 25%;

      background-color: #4c548c;
      color: #f1c232;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    .content-table {
      border-collapse: collapse;
      margin: 25px 0;
      font-size: 0.9em;
      min-width: 400px;
      border-radius: 5px 5px 0 0;
      overflow: hidden;
    }

    .content-table thead tr {
      background-color: #4c548c;
      color: #f1c232;
      text-align: left;
      font-family: sans-serif;
      font-weight: bold;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    }

    .content-table td {
      padding: 12px 15px;

    }

    .content-table tbody tr:nth-of-type(odd) {
      background-color: #D1E3FA;
    }
  </style>
</head>

<body>
  <div class="container-fluid">
    <div style="background-color:#96A5D4;color:#ffffff;" class="row">
      <div class="col-1">
      </div>
      <div class="col">
        <br>
        <?php echo '<h5> Welcome <span class="text-warning">' . $_SESSION["fname"] .' '. $_SESSION["lname"]. ' </span>!</h5>';?>
      </div>
    </div>
  </div>

  <div style="background-color:#4c548c;" class="row">
    <div class="col-1"></div>

    <div class="col">
      <nav style="background-color:#4c548c;" class="navbar navbar-expand-sm navbar-light size">
        <a href="home.php"><img class"d-inline-block align-top" src="logo.png" width="60" height="60" /> </a>
        <div class="collapse.navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a href="driver_schedule.php" class="nav-link " style="color:#d1d5e4">My Schedule</a>
            </li>
            <li class="nav-item">
              <a href="Driver_info.php" class="nav-link" style="color:#d1d5e4">My Information</a>
            </li>

            <li class="nav-item">
              <a href="driver_annou.php" class="nav-link  text-warning" style="color:#d1d5e4">Announcements</a>
            </li>

            <span class="navbar-nav">
            <button type="button" style="font-size: 100%;" class="btn btn-warning"> <a style="font-size: 100%;" class="btn p-0 " href="logout.php">Log Out</a> </button>
            </span>
          </ul>
        </div>
      </nav>
    </div>
  </div>
  <br>

  <h3 class="text-center" style="color:#4c548c;">Announcements</h3>

  <div class="container">

  <div class="table-responsive">
     <table class="table table-hover">

    <table class="table table-striped content-table" style="width:100%">
      <thead>
        <tr>
          <th class="text-center"> ID</th>
         <!-- <th class="text-center"> Admin </th>-->
         <th class="text-center"> Date</th>
          <th class="text-center ">Message</th>
        </tr>
      </thead>
      <!-- الصفوف التاليه تظهر بال php و SQL -->
      <tbody>
        <?php
      $conn = mysqli_connect("localhost","root","","pickme");
if($conn-> connect_error){
die("Connection failed:".$conn-> connect_error);
}
$sql ="SELECT id,date, text from announcement";
$result = $conn-> query($sql);

if ($result-> num_rows > 0){
    while ($row = $result-> fetch_assoc()){
echo '<tr><td class="text-center">'.$row["id"]."</td>"
."<td>".$row["date"]."</td>".
"<td>".$row["text"]."</td></tr>";
    }
   
    echo "</table>";
}else{
    echo "0 result";
}
$conn-> close();

?>




    </table>
    </div>
    </div>


</body>

</html>
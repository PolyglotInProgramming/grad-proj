<?php
  session_start();
  include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>driver's Information</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!--for icons-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

  <style>
    .navbar-nav>span {
      padding-left: 400px;
      padding-right: 0px;
    }

    .size {
      font-size:100%;
      text-align: center;

    }

    .card {
      margin-bottom: 20px;
    }

    input[type=text],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
      background-color: #ffffff;
    }

    input[type=email],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
      background-color: #ffffff;
    }

    input[type=password],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
      background-color: #ffffff;
    }

    input[type=number],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
      background-color: #ffffff;
    }

    input[type=date],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
      background-color: #ffffff;
    }



    div.container {
      border-radius: 5px;
      background-color: #f2f2f2;
      padding: 20px;
    }
    a
    {
      text-decoration:none ;
    }
  </style>
</head>

<body>
  <div class="container-fluid">
    <div style="background-color:#96A5D4;color:#ffffff;" class="row">
      <div class="col-1">
      </div>
      <div class="col">
        <br>
        <?php echo '<h5> Welcome <span class="text-warning">' . $_SESSION["fname"] .' '. $_SESSION["lname"]. ' </span>!</h5>';?>
      </div>
    </div>
  </div>

  <div style="background-color:#4c548c;" class="row">
    <div class="col-1"></div>

    <div class="col">
      <nav style="background-color:#4c548c;" class="navbar navbar-expand-sm navbar-light size">
        <a href="#"><img class="d-inline-block align-top" src="logo.png" width="60" height="60" /> </a>
        <div class="collapse.navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a href="driver_schedule.php" class="nav-link " style="color:#d1d5e4">My Schedule</a>
            </li>
            <li class="nav-item">
              <a href="Driver_info.php" class="nav-link text-warning" style="color:#d1d5e4">My Information</a>
            </li>

            <li class="nav-item">
              <a href="driver_annou.php" class="nav-link" style="color:#d1d5e4">Announcements</a>
            </li>

            <span class="navbar-nav">
            <button type="button" style="font-size: 100%;" class="btn btn-warning"> <a style="font-size: 100%;" class="btn p-0 " href="logout.php">Log Out</a> </button>
            </span>
          </ul>
        </div>
      </nav>
    </div>
  </div>
  <br>
  <h3 class="text-center" style="color:#4c548c;">My Information</h3>
  <br>  <h4 class="text-center" style="color:#4c548c;">*Contact the admin to update your information at <a href="mailto:Admin_PickMe@gmail.com">Admin_PickMe@gmail.com</a></h4>
  <div class="container">
  <?php
  $conn = mysqli_connect("localhost","root","","pickme");
if($conn-> connect_error){
die("Connection failed:".$conn-> connect_error);
}

if (isset($_SESSION["fname"])){
$sql ="SELECT id, fname, lname, email, password, phoneno, triptype, city, lictype, licexp, vehicleid from driver";
$fdata = $conn-> query($sql);
   if ($result= $fdata-> fetch_assoc()){
echo  '<label style="color:#4c548c;">'."Driver's ID".'</label>';
echo '<input type="text"   value="'. $_SESSION["id"] .'" disabled>';

   echo   '<label style="color:#4c548c;" for="fname">'."Driver's first name".'</label>';
   echo   '<input type="text" id="fname" name="fname" value="'. $_SESSION["fname"] .' "disabled>';

   echo  '<label style="color:#4c548c;" for="lname">'."Driver's last name".'</label>';
   echo   '<input type="text" id="lname" name="lname" value="'. $_SESSION["lname"] .' "disabled>';
   echo '<label style="color:#4c548c;" for="email">'."Driver's email".'</label>';
   echo '<input type="email" size="50" id=" email" value="'. $_SESSION["email"] .'" disabled>';


  echo ' <label style="color:#4c548c;" for="number">'."Driver's Phone number".'</label>';
  echo ' <input type="text" id="number" name="phoneno" value="'. $_SESSION["phoneno"] .'"  disabled>'; 
   
   echo '<label style="color:#4c548c;" ">'."city".'</label>';
   echo '<input type="text"  value="'. $_SESSION["city"] .'"  disabled>';
   
   echo '<label style="color:#4c548c;" ">'."Trip Type".'</label>';
   echo '<input type="text"  value="'. $_SESSION["triptype"] .'"  disabled>';
  
   echo '<label style="color:#4c548c;" ">'."licence type".'</label>';
   echo '<input type="text"  value="'. $_SESSION["lictype"] .'"  disabled>';
   echo '<label style="color:#4c548c;" ">'."licences expiration date".'</label>';
   echo '<input type="text" value="'. $_SESSION["licexp"] .'"  disabled>';

  
}}
     
  else{
      echo "0 result";
  }
  $conn-> close();
  
  ?>

<?php
  $con = mysqli_connect('localhost','root','','pickme');
   $k=mysqli_query($con,"SELECT vehicle.id, vehicle.vehiclename FROM driver INNER JOIN vehicle ON driver.vehicleid=vehicle.id WHERE driver.id ='$_SESSION[id]';");



  $o=mysqli_fetch_assoc($k);
     
   echo '<label style="color:#4c548c;" >'."Driver's Vehicle".'</label>';
   echo '<input type="text" value="'.$o['vehiclename'].'"  disabled>';

      ?>
 

</body>

</html>

<!--
<?php /*
  session_start();
  include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>driver's Information</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!--for icons-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

  <style>
    .navbar-nav>span {
      padding-left: 400px;
      padding-right: 0px;
    }

    .size {
      font-size: 80%;
      text-align: center;

    }

    .card {
      margin-bottom: 20px;
    }

    input[type=text],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
      background-color: #ffffff;
    }

    input[type=email],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
      background-color: #ffffff;
    }

    input[type=password],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
      background-color: #ffffff;
    }

    input[type=number],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
      background-color: #ffffff;
    }

    input[type=date],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
      background-color: #ffffff;
    }



    div.container {
      border-radius: 5px;
      background-color: #f2f2f2;
      padding: 20px;
    }
  </style>
</head>

<body>
  <div class="container-fluid">
    <div style="background-color:#96A5D4;color:#ffffff;" class="row">
      <div class="col-1">
      </div>
      <div class="col">
        <br>
        <?php echo '<h5> Welcome <span class="text-warning">' . $_SESSION["fname"] .' '. $_SESSION["lname"]. ' </span>!</h5>';?>
      </div>
    </div>
  </div>

  <div style="background-color:#4c548c;" class="row">
    <div class="col-1"></div>

    <div class="col">
      <nav style="background-color:#4c548c;" class="navbar navbar-expand-sm navbar-light size">
        <a href="#"><img class="d-inline-block align-top" src="logo.png" width="60" height="60" /> </a>
        <div class="collapse.navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a href="driver_schedule.php" class="nav-link " style="color:#d1d5e4">My Schedule</a>
            </li>
            <li class="nav-item">
              <a href="Driver_info.php" class="nav-link text-warning" style="color:#d1d5e4">My Information</a>
            </li>

            <li class="nav-item">
              <a href="driver_annou.php" class="nav-link" style="color:#d1d5e4">Announcements</a>
            </li>

            <span class="navbar-nav">
            <button type="button" style="font-size: 100%;" class="btn btn-warning"> <a style="font-size: 100%;" class="btn p-0 " href="logout.php">Log Out</a> </button>
            </span>
          </ul>
        </div>
      </nav>
    </div>
  </div>
  <br>
  <h3 class="text-center" style="color:#4c548c;">My Information</h3>
  <div class="container">
  <?php
  $conn = mysqli_connect("localhost","root","","pickme");
if($conn-> connect_error){
die("Connection failed:".$conn-> connect_error);
}

if (isset($_SESSION["fname"])){
$sql ="SELECT id, fname, lname, email, password, phoneno, triptype, city, lictype, licexp, vehicleid from driver";
$fdata = $conn-> query($sql);
   if ($result= $fdata-> fetch_assoc()){
echo  '<label style="color:#4c548c;">'."Driver's ID".'</label>';
echo '<input type="text"   value="'. $_SESSION["id"] .'" disabled>';

   echo   '<label style="color:#4c548c;" for="fname">'."Driver's first name".'</label>';
   echo   '<input type="text" id="fname" name="fname" value="'. $_SESSION["fname"] .' "disabled>';

   echo  '<label style="color:#4c548c;" for="lname">'."Driver's last name".'</label>';
   echo   '<input type="text" id="lname" name="lname" value="'. $_SESSION["lname"] .' "disabled>';
   echo '<label style="color:#4c548c;" for="email">'."Driver's email".'</label>';
   echo '<input type="email" size="50" id=" email" value="'. $_SESSION["email"] .'" disabled>';


  echo ' <label style="color:#4c548c;" for="number">'."Driver's Phone number".'</label>';
  echo ' <input type="text" id="number" name="phoneno" value="'. $_SESSION["phoneno"] .'"  disabled>'; 
   
   echo '<label style="color:#4c548c;" ">'."city".'</label>';
   echo '<input type="text"  value="'. $_SESSION["city"] .'"  disabled>';
   
   echo '<label style="color:#4c548c;" ">'."Trip Type".'</label>';
   echo '<input type="text"  value="'. $_SESSION["triptype"] .'"  disabled>';
  
   echo '<label style="color:#4c548c;" ">'."licence type".'</label>';
   echo '<input type="text"  value="'. $_SESSION["lictype"] .'"  disabled>';
   echo '<label style="color:#4c548c;" ">'."licences expiration date".'</label>';
   echo '<input type="text" value="'. $_SESSION["licexp"] .'"  disabled>';

  
}}
     
  else{
      echo "0 result";
  }
  $conn-> close();
  
  ?>

<?php
 /*  $con = mysqli_connect('localhost','root','','pickme');
   $s=mysqli_query($con,"select id, vehiclename from vehicle");?>
    <retrieve name="vehicleid">
      
     if($r =mysqli_fetch_array($s))
     { 
      <option disabled value='."echo $r["id"]".';?>"><?php echo $r['id'].$r['vehiclename'];?></option>     
     }
      
     
   echo '<label style="color:#4c548c;" >'."Driver's Vehicle".'</label>';
   echo '<input type="text" value="'. $_SESSION['vehicleid'].'"  disabled>';
      */?>
 

</body>

</html>-->
<?php
  session_start();
  include 'connection.php';

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password=md5($password);
    $select = "SELECT * FROM driver WHERE email = '$email' AND password = '$password'";
    $result = mysqli_query($conn, $select);
    if (mysqli_num_rows($result) == 1 ) {
        $result = mysqli_fetch_array($result);
        $_SESSION["id"] = $result['id'];
         $_SESSION["fname"] = $result['fname'];
       $_SESSION["lname"] = $result['lname'];
       $_SESSION["email"] = $result['email'];
        $_SESSION["password"] = $result['password'];
        $_SESSION["phoneno"] = $result['phoneno'];
        $_SESSION["triptype"] = $result['triptype'];
        $_SESSION["city"] = $result['city'];
        $_SESSION["lictype"] = $result['lictype'];
        $_SESSION["licexp"] = $result['licexp'];
        $_SESSION["vehicleid"] = $result['vehicleid'];
        
        header("Location:driver_schedule.php");
    } else {
        $_SESSION['loginStatus'] = "Invalid Email or Password!";
        header("Location:driver_login.php");
    }

  }

?>
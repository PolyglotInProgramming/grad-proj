<?php
  session_start();
  include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Schedule</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!--for icons-->
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">


<style>


    .navbar-nav>span {
      padding-left: 400px;
      padding-right: 0px;
    }
.modal-header {
background-color: #96A5D4;
color: #ffffff;
}
    .size {
      font-size: 100%;
      text-align: center;

    }

    i {
      color: #4c548c;
    }

    i:hover {
      color: #f1c232;
    }

    .card {
      margin-bottom: 20px;
    }

    .bttn {
      width: 75%;

      background-color: #4c548c;
      color: #ffffff;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 20px;
      cursor: pointer;
    }

    .content-table {
      border-collapse: collapse;
      margin: 25px 0;
      font-size: 0.9em;
      min-width: 400px;
      border-radius: 5px 5px 0 0;
      overflow: hidden;
    }

    .content-table thead tr {
      background-color: #4c548c;
      color: #f1c232;
      text-align: left;
      font-family: sans-serif;
      font-weight: bold;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    }

    .content-table td {
      padding: 12px 15px;

    }

    .content-table tbody tr:nth-of-type(odd) {
      background-color: #D1E3FA;
    }

    .gray {
      background-color: gray;
    }

    .yellow {
      background-color: yellow;
    }

    .green {
      background-color: green;
    }

    .red {
      background-color: red
    }
    p{
font-size: 15px;
text-align: center;
font-weight: 500;
    }
  </style>
</head>

<body>
  <div class="container-fluid">
    <div style="background-color:#96A5D4;color:#ffffff;" class="row">
      <div class="col-1">
      </div>
      <div class="col">
        <br>
        <?php echo '<h5> Welcome <span class="text-warning">' . $_SESSION["fname"] .' '. $_SESSION["lname"]. ' </span>!</h5>';?>
      </div>
    </div>
  </div>

  <div style="background-color:#4c548c;" class="row">
    <div class="col-1"></div>

    <div class="col">
      <nav style="background-color:#4c548c;" class="navbar navbar-expand-sm navbar-light size">
        <a href="#">
          <class="navbar-brand mb-0 h1">

            <img class="d-inline-block align-top" src="logo.png" width="60" height="60" />
            <div class="collapse.navbar-collapse" id="navbarNav">
              <ul class="navbar-nav">
                <li class="nav-item">

                  <a href="driver_schedule.php" class="nav-link text-warning " style="color:#d1d5e4">My Schedule</a>
                </li>
                <li class="nav-item">
                  <a href="Driver_info.php" class="nav-link " style="color:#d1d5e4">My Information</a>
                </li>

                <li class="nav-item">
                  <a href="driver_annou.php" class="nav-link" style="color:#d1d5e4">Announcements</a>
                </li>

                <span class="navbar-nav">
                <button type="button" style="font-size: 100%;" class="btn btn-warning"> <a style="font-size: 100%;" class="btn p-0 " href="logout.php">Log Out</a> </button>
                </span>
              </ul>
            </div>
      </nav>
    </div>
  </div>
  <br>

  <!----------------------->
  <br>
  <h4 style="color:#4c548c;">
    <center>Schedule</center>
  </h4>
  <?php
if (isset($_SESSION["changestatus"])) {
  if($_SESSION["changestatus"] == "The status changed successfully"){
    echo '<center>';
    echo '<h5 class="text-success">'. $_SESSION['changestatus'].'</h5>';
    echo '</center>';
  }

unset($_SESSION["changestatus"]);
}

?>
  <?php
if (isset($_SESSION["changestat"])) {
  if($_SESSION["changestat"] == "The status changed successfully"){
    echo '<center>';
    echo '<h5 class="text-success">'. $_SESSION['changestat'].'</h5>';
    echo '</center>';
  }

unset($_SESSION["changestat"]);
}

?>
  <div class="container">

  <div class="table-responsive">
     <table class="table table-hover">

    <table class="table table-striped content-table" style="width:100%">
      <thead>
        <tr>
          <th class="text-center">ID</th>
          <th class="text-left">Date</th>
          <th class="text-left">Pick up time</th>
          <th class="text-left">Pick up location</th>
          <th class="text-left">Drop off time</th>
          <th class="text-left">Drop off location</th>
          <th class="text-left">customer name</th>
          <th class="text-left">Phone number</th>          
          <th class="text-center">Change Status</th>
          <th class="text-center">Current Status</th>
        </tr>
      </thead>
      <tbody>
        <?php 
        $id=$_SESSION["id"];
        $sql ="SELECT *  from reservation_details WHERE driverid='$id' AND (status='paid' or status='dropped off' or status='picked up') ORDER BY date,pickuptime ASC";
        $sqll = mysqli_query($conn,$sql);
        if(mysqli_num_rows($sqll)>0){
          foreach ($sqll as $row) {
          ?>
        <tr>
          <td> <?= $row['RID']; ?></td>
          <td> <?= $row['date']; ?></td>
          <td> <?= $row["pickuptime"] ?></td>
          <td> <?= $row["pickuplocation"] ?></td>
          <td> <?= $row["dropofftime"]; ?></td>
          <td> <?= $row["dropofflocation"]; ?></td>
          <td> <?= $row['customername']; ?></td>
          <td> <?= $row['customerno']; ?></td>


<td class="text-center">
          <?php
 if( $row["status"]=='paid'){?>
  <form action="reservation_status.php" method="POST"
<center><button type="submit" style="font-size: 13px;" name="changestatus" class="btn btn-warning p-1 " data-bs-toggle="modal" data-bs-target ="#myModal">Pick up</button></center> 


<input type="hidden" value="<?= $row['status']; ?>" name="status">
<div class="mb-3">
 
 <input type="hidden" value="<?= $row['RID']; ?>" name="RID">
 



</form>

   </td>

<?php
}elseif($row["status"]=='picked up'){?>
  <form action="reservation_status.php" method="POST">
  <center><button type="submit" style="font-size: 13px;" name="changestat" class="btn btn-success p-1" data-bs-toggle="modal" data-bs-target ="#myModal">Drop off</button></center> 

  
  
  
  
  
 
  <input type="hidden" value="<?= $row['status']; ?>" name="status">
  <div class="mb-3">

   <input type="hidden" value="<?= $row['RID']; ?>" name="RID">
   
  </div>
  
  
  </form>
   
  
     </td>
 <?php
}elseif($row["status"]=='dropped off'){
  echo " <center><span style='font-size: 13px;' class='btn btn-secondary p-1  '>Delivered</span> </center></td>";
  echo "</td>";  
}
?>
        <!-- 
        btn btn-success p-1 
            <td> <select name="color" onchange="changeColor()">
              <option  value="select">---Select---</option>
              <option class="gray" value="pending">Pending</option>
              <option class="yellow" value="Picked up">Picked up</option>
              <option class="green" value="Dropped off">Dropped off</option>
              <option class="red hover" value="Canceled">Canceled</option> 
              <script src="color.js"></script>
            </select>           
          </td>-->

</form>

          <td>
          <?php
 if( $row["status"]=='dropped off'){
  echo " <p class=' text-success'>Dropped off</p></td>";
   echo "</td></tr>"; 


}elseif($row["status"]=='picked up'){
  echo " <p class='  text-warning right'>Picked up</p></td>";
  echo "</td></tr>"; 
 
}elseif($row["status"]=='paid'){
  echo " <p class=' text-info'>Paid</p></td>";
  echo "</td></tr>";  
}
}?>

            
<?php
//ممنوع اللمس
         
  
     } else{
?>
        <tr>
        <center> no reccord found </center>          
        </tr>

  </table>
<?php
        }
        ?>
  </table>
  </div>
  </div>




<!--
    <td> <select name="color" onchange="changeColor()">
    <option  value="select">---Select---</option>
        <option class="gray " value="pending">Pending</option>
        <option class="yellow " value="Picked up">Picked up</option>
        <option class="green " value="Dropped off">Dropped off</option>
            <option class="red hover" value="Canceled">Canceled</option> 

        <td> <span class='badge bg-success'>Dropped off</span></td>--><!--for customer only-->


<!--
        <td> <select name="color" onchange="changeColor()">
          <option  value="select">---Select---</option>
              <option class="gray" value="pending">Pending</option>
              <option class="yellow" value="Picked up">Picked up</option>
              <option class="green" value="Dropped off">Dropped off</option>
                  <option class="red hover" value="Canceled">Canceled</option> 

              <script src="color.js"></script>
            </select>
          <td> <span class='badge bg-success'>Dropped off</span></td>
  </div>
  </div>
  </td>
  --><!--for customer only-->





<!--
  <td> <select name="color" onchange="changeColor()">
    <option  value="select">---Select---</option>
        <option class="gray " value="pending">Pending</option>
        <option class="yellow " value="Picked up">Picked up</option>
        <option class="green " value="Dropped off">Dropped off</option>
        <option class="red " value="Canceled">Canceled</option> 
    <td> <span class='badge bg-success'>Dropped off</span></td>
-->        <!--for customer only-->

</body>

</html>
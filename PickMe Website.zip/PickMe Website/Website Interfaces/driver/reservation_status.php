<?php
  session_start();
  include 'connection.php';

if (isset($_POST['changestatus'])) {
    $RID= $_POST['RID'];
    $status = $_POST['status'];
 
    $select = "UPDATE reservation_details SET status='picked up' WHERE RID ='$RID'";
    $result = mysqli_query($conn, $select);
    $_SESSION["changestatus"] = "The status changed successfully";
   header("Location:driver_schedule.php?RID=$RID");
   
       
    }

  

?>

<?php

if (isset($_POST['changestat'])) {
    $RID= $_POST['RID'];
    $status = $_POST['status'];
 
    $select = "UPDATE reservation_details SET status='dropped off' WHERE RID ='$RID'";
    $result = mysqli_query($conn, $select);
    $_SESSION["changestat"] = "The status changed successfully";
   header("Location:driver_schedule.php?RID=$RID");
   
       
    }

  

?>
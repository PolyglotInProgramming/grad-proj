<?php
session_start();
include('connection.php');

//\\// reserve \\//\\
if (isset($_POST['viseterReserve'])) {

  if (isset($_SESSION['id'])) {
    header("Location:customer/customer_home.php");

  } elseif (!isset($_SESSION['id'])) {
    header("Location:customer/customer_login.php");

  }

}
    


?>
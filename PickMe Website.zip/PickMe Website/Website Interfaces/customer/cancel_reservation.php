<?php
  session_start();
  include 'connection.php';
?>

<?php
//canceling
if (isset($_POST['cancel'])) {
 $Rid= $_POST['cancel'];
  $status = $_POST['status'];
    
     
 if ($status  == 'pending'){ 
  //delete 
  $q = "UPDATE reservation SET status='canceled' WHERE Rid='$Rid' ";
  $r = mysqli_query($conn,$q);
    
    if($r){
        $_SESSION["cancel"] = "The Schedule canceled successfully";
        header("Location:customer_reservation.php");
    } else {
      $_SESSION["cancel"] = "Only pending reservations can be canceled";
      header("Location:customer_reservation.php");
    }
    
  } else { 
    //realy reserved
    $_SESSION["cancel"] = "Only pending reservations can be canceled";
    header("Location:customer_reservation.php");
  }
  }

  //-------------------------------------------------------------------------------------------------------

?>

<?php
if (isset($_POST['pay'])) {
  //$Rid = $_GET['RID'];
  $RID = $_SESSION['RID'];
  $id = $_SESSION["id"];
  $EXPdate = $_POST['EXPdate'];
  $cardno = $_POST['cardno'];
  $cvv = $_POST['cvv'];

  $s = "SELECT status from reservation WHERE Rid = ' $RID'";
  $r = mysqli_query($conn, $s);



  if ($r->num_rows > 0)
    $row = $r->fetch_assoc();
/*
  if ($row["status"] == 'canceled') {
    $_SESSION["statuspayment"] = "You can't pay for canceled reservations";
    header("Location:customer_reservation.php");

  } elseif ($row["status"] == 'paid' or 'picked up' or 'dropped off') {
    $_SESSION["statuspayment"] = "The reservation is already paid";
    header("Location:customer_reservation.php");

  } else
  */if ($row["status"] == 'pending') {

    $pay = "INSERT INTO payment (customerid,reservationid,cardno, cvv,expdate) VALUES ('$id',' $RID',' $cardno','$cvv','$EXPdate')";
    $update = "UPDATE reservation SET status = 'paid' WHERE Rid = '$RID'";
    mysqli_query($conn, $pay);
    mysqli_query($conn, $update);

    $_SESSION["statuspayment"] = "Paid Successfully!";
    header("Location:customer_reservation.php");
  }

}

?>







<?php
/*

    $_SESSION['payment'] = "You are registered sucessfully.";
    header("Location:Registration.php");

   
        $_SESSION["payment"] = "Paid Successfully!";
        header("Location:customer_pay.php");
    } else {
      $_SESSION["payment"] = "Something went wrong";
      header("Location:customer_pay.php");
    }


if (isset($_POST['pay'])) {
 $Rid= $_POST['pay'];

  $_SESSION["Rid"] = $Rid;
    $_SESSION["status"]= $_POST['status'];
     
 if ( $_SESSION["status"]  == 'pending'){ 
  //delete 
    
   
        $_SESSION["pay"] = "";
        header("Location:customer_pay.php");
        } elseif($_SESSION["status"]  == 'canceled')
        {
          $_SESSION["pay"] = "You can't pay for canceled reservations";
          header("Location:customer_reservation.php");
       
    } else {
      $_SESSION["pay"] = "The reservation is already paid";
      header("Location:customer_reservation.php");
    }
  
  }

  if ($_SESSION["status"]  == 'pending'){ //زر الدفع }else{}

*/
?>
///\\\\\\\\\\\\\\\\\\\\\\\\\for payment page/////////\\\\\\\\📌📌📌📌📌📌📌📌📌📌📌📌📌📌📌📌✉️✉️✉️✉️
<?php
/*
if (isset($_POST['payment'])) {
 // $Rid= $_POST['cancel']; 

  $Rid=$_SESSION["Rid"] ; 
 $id=$_SESSION["id"];
//   $_SESSION["status"]= $_POST['status'];
 $EXPdate= $_POST['EXPdate'];
 $cardno= $_POST['cardno'];
 $cvv= $_POST['cvv'];
    
   
    $pay = "INSERT INTO payment (customerid,reservationid,cardno, cvv,expdate) VALUES ('$id',' $Rid',
    ' $cardno','$cvv','$EXPdate')";
    mysqli_query($conn,$payment);
    $_SESSION['payment'] = "You are registered sucessfully.";
    header("Location:Registration.php");

   
        $_SESSION["payment"] = "Paid Successfully!";
        header("Location:customer_pay.php");
    } else {
      $_SESSION["payment"] = "Something went wrong";
      header("Location:customer_pay.php");
    }
  


  */
?>

 
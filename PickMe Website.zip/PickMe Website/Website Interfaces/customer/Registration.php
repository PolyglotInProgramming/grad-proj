<?php
include 'Registr.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Registration</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

  <style>
    #number:focus{
      outline: 0;
    }
    #number:valid{
      border-color: green;
    }
    #number:focus:invalid{
      border-color: red;
    }
    #fn:focus{
      outline: 0;
    }
    #fn:valid{
      border-color: green;
    }
    #fn:focus:invalid{
      border-color: red;
    }
    #ln:focus{
      outline: 0;
    }
    #ln:valid{
      border-color: green;
    }
    #ln:focus:invalid{
      border-color: red;
    }
  </style>
</head>
<body>
  
<div class="container-fluid ">
<div class="row">
        <div class="col-sm-12 p-2 bg-light text-white">
        </div>
</div>

  <div class="row">
    <div class="col-sm-3 p-3 bg-light text-white"></div>
    <!--  <div  class="col-sm-4 p-3 bg-warning text-white ">-->  

    <div style ="background-color: #94a4d4;" class="col-sm-6 p-3  text-white ">
        <center><img src="logo.png"  style="width:15%;" alt="Website Logo"></center>
    <h2  class="text-warning"><center> Customer Sign up </center> </h2>
   <br>
        
        <form action="Registr.php" method="POST">

          <div class="row"> 
            <div class="col-1"></div>       
          <div class="col-5">
            <label ><b>Enter your first name:</b></label>
          </div>
          <div class="col-6">
            <input type="text" id="fn" pattern="[A-Za-z\s]{3,30}" placeholder="First name" maxlength="30" name="fname" required>
            <br>
            <br>
          </div>  
          </div>        

          <div class="row">    
          <div class="col-1"></div>           
          <div class="col-5">
             <label ><b>Enter your last name:</b></label>
          </div>
          <div class="col-6">
            <input type="text" id="ln" pattern="[A-Za-z\s]{3,30}" placeholder="Last name" maxlength="50" name="lname" required>
            <br>
            <br>
          </div>  
          </div>  

          <div class="row">        
          <div class="col-1"></div>           
          <div class="col-5">
           <label ><b>Choose your gender:</b></label>
          </div>
          <div class="col-6">
           <label> <input type="radio" value="Female" name="gender" required> Female</label> 
           <label> <input type="radio" value="Male" name="gender" required> Male</label> 
            <br>
            <br>
          </div>  
          </div> 


          <div class="row">        
          <div class="col-1"></div>           
          <div class="col-5">
            <label ><b>Enter your email:</b></label>
          </div>
          <div class="col-6">
           <input type="email" placeholder="email" maxlength="50" name="email" required>
            <br>
            <br>
          </div>  
         </div> 

          <div class="row">        
          <div class="col-1"></div>           
          <div class="col-5">            
            <label ><b>Enter your phone number:</b></label>
          </div>
          <div class="col-6">
          <input type="tel" id="number" name="phoneno" maxlength="12" placeholder="05xx-xxx-xxx" pattern="[0-9]{4}-[0-9]{3}-[0-9]{3}" required>


            <br>
            <br>
          </div>  
          </div> 


          <div class="row">        
            <div class="col-1"></div>           
            <div class="col-5">            
              <label ><b>City</b> </label>
            </div>
            <div class="col-6">
              <select name="city" required>
                <option value="Riyadh">Riyadh</option>
                <option value="Dammam">Dammam</option>
                <option value="Jeddah">Jeddah</option>
                <option value="Medina">Medina</option>
                <option value="Mecca">Mecca</option>
                <option value="Taif">Taif</option>
                <option value="Al-Ahsa">Al-Ahsa</option>
                <option value="Hafar Al Batin">Hafar Al Batin</option>
                <option value="Hail">Hail</option>
                <option value="Tabuk">Tabuk</option>
                <option value="Arar">Arar</option>
                <option value="Jazan">Jazan</option>
                <option value="Najran">Najran</option>
                <option value="Al Bahah">Al Bahah</option>
                <option value="Al-Qasim">Al-Qasim</option>
                <option value="Jouf">Jouf</option>
                <option value="Aseer">Aseer</option>
        
              </select>  
              <br>
              <br>
            </div>  
            </div> 


          <div class="row">        
          <div class="col-1"></div>           
          <div class="col-5">             
          <label ><b>Enter your password:</b></label>
          </div>
          <div class="col-6">
           <input type="password" placeholder="Password" maxlength="8" name="password" required>
            <br>
            <br>
          </div>  
          </div> 

          <?php
              if(isset($_SESSION['regesterStatus'])){

                if( $_SESSION['regesterStatus'] == "You are registered sucessfully."){
              echo '<center>';
              echo '<h5 class="text-success">'. $_SESSION['regesterStatus'].' '. '<a href="customer_login.php">You can login now!</a>'. '</h5>';
                echo '</center>';
              }else if($_SESSION['regesterStatus'] == "Email already registered."){
                echo '<center>';
              echo '<h5 class="text-danger">' . $_SESSION['regesterStatus'] . '</h5>';
                echo '</center>';
              }
              unset($_SESSION['regesterStatus']);
            }
          ?>


        <center><input type="submit" onclick="" class="btn btn-light" name="registr" value="Sign Up!"></input></center> 
        <center><a class="btn"  href="customer_login.php">Already have account !</a>
        <br>
        <a class="btn  py-0 px-2" href="../Home.php">Home</a>

      </center>

        </form>
    </div>
    



    <div class="col-sm-3 p-4 bg-light text-white"></div>

  </div>

  <div class="row">
    <div class="col-sm-12 p-2 bg-light text-white">
    </div>
</div>
</body>
</html>


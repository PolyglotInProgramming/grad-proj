<?php
  session_start();
  include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Customer Information</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!--for icons-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

  <style>
    .navbar-nav>span {
      padding-left: 400px;
      padding-right: 0px;
    }

    .size {
      font-size: 100%;
      text-align: center;

    }

    .card {
      margin-bottom: 20px;
    }

    input[type=text],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
      background-color: #ffffff;
    }

    input[type=email],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
      background-color: #ffffff;
    }

    input[type=password],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
      background-color: #ffffff;
    }

    input[type=number],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
      background-color: #ffffff;
    }

    input[type=tel],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
      background-color: #ffffff;
    }
    input[type=submit] {
      width: 100%;
      background-color: #4c548c;
      color: #f1c232;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }


    div.container {
      border-radius: 5px;
      background-color: #f2f2f2;
      padding: 20px;
    }

    #number:focus{
      outline: 0;
    }
    #number:valid{
      border-color: green;
    }
    #number:focus:invalid{
      border-color: red;
    }
    #fn:focus{
      outline: 0;
    }
    #fn:valid{
      border-color: green;
    }
    #fn:focus:invalid{
      border-color: red;
    }
    #ln:focus{
      outline: 0;
    }
    #ln:valid{
      border-color: green;
    }
    #ln:focus:invalid{
      border-color: red;
    }
  </style>
</head>

<body>
  <div class="container-fluid">
    <div style="background-color:#96A5D4;color:#ffffff;" class="row">
      <div class="col-1">
      </div>
      <div class="col">
        <br>
        <?php echo '<h5> Welcome <span class="text-warning">' . $_SESSION["fname"] .' '. $_SESSION["lname"]. ' </span>!</h5>';?>
      </div>
    </div>
  </div>

  <div style="background-color:#4c548c;" class="row">
    <div class="col-1"></div>

    <div class="col">
      <nav style="background-color:#4c548c;" class="navbar navbar-expand-sm navbar-light size">
        <a href="home.html"><img class="d-inline-block align-top" src="logo.png" width="60" height="60" /></a>

            <div class="collapse.navbar-collapse" id="navbarNav">
              <ul class="navbar-nav">
                <li class="nav-item">
                  <a href="customer_home.php" class="nav-link" style="color:#d1d5e4">HOME</a>
                </li>
                <li class="nav-item">
                  <a href="customer_info.php" class="nav-link text-warning">My Information</a>
                </li>
                <li class="nav-item">
                  <a href="customer_reservation.php" class="nav-link " style="color:#d1d5e4">My Reservations</a>
                </li>
                <li class="nav-item">
                  <a href="customer_feedback.php" class="nav-link" style="color:#d1d5e4">Give Feedback</a>
                </li>

                <span class="navbar-nav">
                  <button type="button" style="font-size: 100%;" class="btn btn-warning"> <a style="font-size: 100%;" class="btn p-0 " href="logout.php">Log Out</a> </button>
                </span>
              </ul>
            </div>
      </nav>
    </div>
  </div>
  <br>


  <h3 class="text-center" style="color:#4c548c;">My Information</h3>


      <?php
if(isset($_SESSION['id'])){
  $customer_id =$_SESSION['id'];

$customer = "SELECT *  FROM customer WHERE id='$customer_id'";
$customer_run = mysqli_query($conn, $customer);
  if(mysqli_num_rows($customer_run) > 0){
    foreach ($customer_run as $customer) {
      ?>

     <?php
      if(isset($_SESSION['editCustomer'])){
echo' <center>';
        $_SESSION['editCustomer'] == "Your information updated successfully";
      echo '<h3 class="text-success">'. $_SESSION['editCustomer'].'</h3></center>';
      ///unset($_SESSION['licexpStatus']);
      /*}else if($_SESSION['licexpStatus'] == "Email already registered."){
      
      */}
      unset($_SESSION['editCustomer']);
      }?>
  <div class="container">
    <form style="color:#4c548c;" action="c_login.php" method="POST">

    <input type="hidden" name="customer_id" value="<?=$customer['id']; ?>" >
      <label style="color:#4c548c;" for="fn">Customer's first name</label>
      <input type="text" pattern="[A-Za-z\s]{3,30}" maxlength="30" id="fn" name="fname" value="<?=$customer['fname']; ?>"  >

      <label style="color:#4c548c;" for="ln">Customer's last name</label>
      <input type="text" pattern="[A-Za-z\s]{3,30}" maxlength="30" id="ln" name="lname" value="<?=$customer['lname']; ?>"  >
   

      <label style="color:#4c548c;" for="email">Customer's email</label>
      <input type="email" size="50" id=" email" name="email" value="<?=$customer['email']; ?> " disabled>
      <input type="hidden" size="50" id=" email" name="email" value="<?=$customer['email']; ?>" >
      
      <label style="color:#4c548c;" for="passsword">customer's password</label>
      <input type="password" id="passwords" name="password" maxlength="8"  >

      <label style="color:#4c548c;" for="number">customer's Phone number</label>
      <input type="tel" id="number" name="phoneno" value="<?=$customer['phoneno']; ?>"  placeholder="05xx-xxx-xxx" pattern="[0-9]{4}-[0-9]{3}-[0-9]{3}"  >

      <label style="color:#4c548c;" >Customer's gender</label>
      <input type="text" pattern="[A-Za-z]{4,7}" maxlength="7" id="fn"  name="gender" value="<?=$customer['gender']; ?>"  >


      <label style="color:#4c548c" for="city">City</label>
      <select id="City" name="city"  >
      <option value=" ">--Select--</option> 
        <option value="Riyadh" <?=$customer['city'] == 'Riyadh' ? 'selected' : '' ?>>Riyadh</option>
        <option value="Dammam" <?=$customer['city'] == 'Dammam' ? 'selected' : '' ?>>Dammam</option>
        <option value="Jeddah" <?=$customer['city'] == 'Jeddah' ? 'selected' : '' ?>>Jeddah</option>
        <option value="Medina" <?=$customer['city'] == 'Medina' ? 'selected' : '' ?>>Medina</option>
        <option value="Mecca" <?=$customer['city'] == 'Mecca' ? 'selected' : '' ?>>Mecca</option>
        <option value="Taif" <?=$customer['city'] == 'Taif' ? 'selected' : '' ?>>Taif</option>
        <option value="Al-Ahsa" <?=$customer['city'] == 'Al-Ahsa' ? 'selected' : '' ?>>Al-Ahsa</option>
        <option value="Hafar Al Batin" <?=$customer['city'] == 'Hafar Al Batin' ? 'selected' : '' ?>>Hafar Al Batin</option>
        <option value="Hail" <?=$customer['city'] == 'Hail' ? 'selected' : '' ?>>Hail</option>
        <option value="Tabuk" <?=$customer['city'] == 'Tabuk' ? 'selected' : '' ?>>Tabuk</option>
        <option value="Arar" <?=$customer['city'] == 'Arar' ? 'selected' : '' ?>>Arar</option>
        <option value="Jazan" <?=$customer['city'] == 'Jazan' ? 'selected' : '' ?>>Jazan</option>
        <option value="Najran" <?=$customer['city'] == 'Najran' ? 'selected' : '' ?>>Najran</option>
        <option value="Al Bahah" <?=$customer['city'] == 'Al Bahah' ? 'selected' : '' ?>>Al Bahah</option>
        <option value="Al-Qasim" <?=$customer['city'] == 'Al-Qasim' ? 'selected' : '' ?>>Al-Qasim</option>
        <option value="Jouf" <?=$customer['city'] == 'Jouf' ? 'selected' : '' ?>>Jouf</option>
        <option value="Aseer" <?=$customer['city'] == 'Aseer' ? 'selected' : '' ?>>Aseer</option>
      </select>

        <input type="submit"  name="editCustomer" value="Update Information">
    </form>

    <?php
    }
  } else {
      ?>
<div class="container"><center><h4>No record found</h4></center> </div>
<?php
      }

?>

  </div>


</body>


</html>
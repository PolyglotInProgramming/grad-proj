<?php
session_start();
include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Reset Password</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

  <style>
    .modal-header {
  background-color: #96A5D4;
  color: #ffffff;
}
  </style>
</head>

<body>

  <div class="container-fluid ">
    <div class="row">
      <div class="col-sm-12 p-3 bg-light text-white">
        <br>
      </div>
    </div>

    <div class="row">
      <div class="col-sm-4 p-3 bg-light text-white"></div>
      <!--  <div  class="col-sm-4 p-3 bg-warning text-white ">-->

      <div style="background-color: #94a4d4;" class="col-sm-4 p-3  text-white ">
        <center><img src="logo.png" style="width:20%;" alt="Website Logo"></center>
        <h2 class="text-warning"><center>Customer Reset Password </center></h2>
        <center>
          
        <?php
        if(isset($_GET['email']) && isset($_GET['id'])){
          $customer_id = $_GET['id'];
          $customer_email = $_GET['email'];

          $customerR = "SELECT *  FROM customer WHERE id='$customer_id'";
          $customer_run = mysqli_query($conn, $customerR);
          $customer = $customer_run->fetch_object();

        }
        ?>
        
        <form action="paa_reset.php" method="POST">
          <input type="hidden" name="id" value="<?=$customer->id; ?>">
          <input type="hidden" name="email" value="<?=$customer->email; ?>">

            <label><b>Enter new password:</b></label>
            <br>
            <input type="password" placeholder="password" maxlength="8" name="password" required>
            <br><br>
            <input type="submit" class="btn btn-warning py-0 px-2" name = "resetPass" value="Reset Password"></input>
          </form>
          


<a class="btn  py-0 px-2" href="customer_login.php">Login</a>
          

          <br>
          <!-------------------refuses to be linked------------------>
          <a class="btn  py-0 px-2" href="../Home.php">Home</a>
        </center>
      </div>



      <?php
      /*
      if (isset($_POST['login'])) {
        $email = $_POST['email'];
        $password = $_POST['password'];
        $select = "SELECT * FROM customer WHERE email = '$email' AND password = '$password'";
        $result = mysqli_query($conn,$select);
        //  $row = mysqli_fetch_array($result);
        $row = $r -> fetch_assoc();

        if (mysqli_num_rows($r) > 0) {
          $_SESSION["email"] = $row['email'];
          $_SESSION["password"] = $row['password'];
          $_SESSION["fname"] = $row['fname'];
          $_SESSION["lname"] = $row['lname'];
          header("Location: customer_home.html");
        }else{
          $_SESSION['loginStatus'] = "Invalid Email or Password!";
          header("Location:customer_login.php");
        }
        }

        if(isset($_SESSION["email"])){
          header("Location: customer_home.html");// echo 'Welcome' . " " . $_SESSION["firstname"] . " " . $_SESSION["lastname"]
      } else {
        $_SESSION['loginStatus'] = "Invalid Email or Password!";
      }
      */
      ?>


      <div class="col-sm-4 p-3 bg-light text-white"></div>

    </div>
  </div>
  <div class="row">
    <div class="col-sm-12 p-3 bg-light text-white">
      <br><br>
    </div>





    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>

</html>
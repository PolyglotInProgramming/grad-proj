<?php
  session_start();
  include 'connection.php';
  
  if (isset($_POST['registr'])) {
    $fname = $_POST['fname'];
   $lname = $_POST['lname'];
   $gender = $_POST['gender'];
   $email = $_POST['email'];
    $phoneno = $_POST['phoneno'];
    if(isset($_POST['city'])){$city = $_POST['city'];}
   $password = $_POST['password'];

   $select = "SELECT * FROM customer WHERE email = '$email'";
    $result = mysqli_query($conn,$select);

    if (mysqli_num_rows($result) > 0) {
    $_SESSION['regesterStatus'] = "Email already registered.";
    header("Location:Registration.php");
   } else {
    $hashed_password=md5($password);
    $registr = "INSERT INTO customer (fname,lname,gender,email,phoneno,city,password) VALUES ('$fname','$lname','$gender','$email','$phoneno','$city','$hashed_password')";
    mysqli_query($conn,$registr);
    $_SESSION['regesterStatus'] = "You are registered sucessfully.";
    header("Location:Registration.php");

  }
  }

?>
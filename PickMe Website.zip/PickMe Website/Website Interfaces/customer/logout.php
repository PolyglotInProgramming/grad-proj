<?php
session_start();
session_destroy();
    header("Location:customer_login.php");
/*
ssession_reset();
if (session_destroy()) {
    header("Location:customer_login.php");
}
*/
?>
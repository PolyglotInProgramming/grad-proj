<?php
  session_start();
  include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Customer Give Feedback</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!--for icons-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    .navbar-nav>span {
      padding-left: 400px;
      padding-right: 0px;
    }

    .size {
      font-size: 100%;
      text-align: center;

    }

    .card {
      margin-bottom: 20px;
    }

    input[type=text],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=email],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }
    textarea {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=password],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=number],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=date],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=submit] {
      width: 100%;
      background-color: #4c548c;
      color: #f1c232;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    input[type=reset] {
      width: 100%;
      background-color: #f1c232;
      color: #4c548c;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }


    div.container {
      border-radius: 5px;
      background-color: #f2f2f2;
      padding: 20px;
    }
  </style>
</head>

<body>
  <div class="container-fluid">
    <div style="background-color:#96A5D4;color:#ffffff;" class="row">
      <div class="col-1">
      </div>
      <div class="col">
        <br>
        <?php echo '<h5> Welcome <span class="text-warning">' . $_SESSION["fname"] .' '. $_SESSION["lname"]. ' </span>!</h5>';?>
      </div>
    </div>
  </div>

  <div style="background-color:#4c548c;" class="row">
    <div class="col-1"></div>

    <div class="col">
      <nav style="background-color:#4c548c;" class="navbar navbar-expand-sm navbar-light size">
        <a href="home.html"><img class="d-inline-block align-top" src="logo.png" width="60" height="60" /></a>

            <div class="collapse.navbar-collapse" id="navbarNav">
              <ul class="navbar-nav">
                <li class="nav-item">
                  <a href="customer_home.php" class="nav-link" style="color:#d1d5e4">HOME</a>
                </li>
                <li class="nav-item">
                  <a href="customer_info.php" class="nav-link" style="color:#d1d5e4">My Information</a>
                </li>
                <li class="nav-item">
                  <a href="customer_reservation.php" class="nav-link " style="color:#d1d5e4">My Reservations</a>
                </li>
                <li class="nav-item">
                  <a href="customer_feedback.php" class="nav-link text-warning">Give Feedback</a>
                </li>

                <span class="navbar-nav">
                  <button type="button" style="font-size: 100%;" class="btn btn-warning"> <a style="font-size: 100%;" class="btn p-0 " href="logout.php">Log Out</a> </button>
                </span>
              </ul>
            </div>
      </nav>
    </div>
  </div>
  
  <br>
  <h3 class="text-center" style="color:#4c548c;">Give us your Feedback</h3>
  <div class="container">
  <?php
 if(isset($_SESSION['feedbackstat'])){
 if($_SESSION['feedbackstat'] == "Your feedback will appear on the home page."){
 echo  '<h5 class="text-success">'.$_SESSION['feedbackstat']."</h5>";
 $_SESSION['feedbackstat']="";
/* unset($_SESSION['announcStatus']);}*/
 }}
 ?>
    <form style="color:#4c548c;" action="feed.php" method="POST">
      <label style="color:#4c548c;" for="feed">Enter Your Message</label><br><br>
      <textarea name="text" id="feed" cols="122" rows="5" required></textarea>
        <label style="color:#4c548c;">Customedr ID</label>
  
        
      <input type="text" name="customerid"value="<?php  echo $_SESSION['id'];?>">
      <input type="submit" value="Send Feedback" name="feed">
      <input type="reset" value="Reset">
    </form>
  </div>

</body>

</html>
<?php
  session_start();
  include 'connection.php';
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-5">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Passngers reservation form</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css"
    integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
        <script defer src="https://use.fontawesome.com/releases/v5.15.4/js/all.js" integrity="sha384-rOA1PnstxnOBLzCLMcre8ybwbTmemjzdNlILg8O7z1lUkLXozs4DHonlDtnE7fpc" crossorigin="anonymous"></script>
   
</head>
<style>
  .navbar-nav>span {

    padding-left: 40px;

    padding-right: 0px;

  }



  .size {

    font-size: 80%;

    text-align: center;

  }

  .modal-header {
  background-color: #96A5D4;
  color: #ffffff;
}

</style>

</head>



<body>

  <div class="container-fluid">

    <div style="background-color:#96A5D4; color:#ffffff;" class="row">


      <div class="col">

        <br>

      </div>

    </div>




  </div>

  <p>
    <Center><img src="from airport.jpg" alt="logo2" width="550" height="250"></Center>
  </p>

  <p>
    <center>
      <h2><strong>
          <p style="color: rgba(20, 0, 110, 0.726); font-family:courier;"></p>Reservation Service for passengers
        </strong></h2>
    </center>
  </p>





  <form action="Passengers reservation form.php" method="POST">
    <div class="container">
      <hr>
      <div class="row">
        <div class="col">
          <p>
            <center>
              <label>
                <label for="City">
                  <h4><b>category</b></h4>
                </label><br>
                <h4>
                  <select id="Category" name="category">
                    <option value=" "> --Select--</option>
                    <option value="Standard">Standard</option>
                    <option value="express"> express</option>
                    <option value="First class">First class</option>
                  </select>
                </h4>
            </center>
          </p>
        </div>

        <div class="col">
          <p>
            <center>
              <label for="City">
                <h4><b>city:</b></h4>
              </label><br>
              <h4>
                <select id="City" name="city" >
                  <option value=" ">--Select--</option>
                  <option value="Riyadh">Riyadh</option>
                  <option value="Dammam">Dammam</option>
                  <option value="Jeddah">Jeddah</option>
                  <option value="Medina">Medina</option>
                  <option value="Mecca">Mecca</option>
                  <option value="Taif">Taif</option>
                  <option value="Al-Ahsa">Al-Ahsa</option>
                  <option value="Hafar Al Batin">Hafar Al Batin</option>
                  <option value="Hail">Hail</option>
                  <option value="Tabuk">Tabuk</option>
                  <option value="Arar">Arar</option>
                  <option value="Jazan">Jazan</option>
                  <option value="Najran">Najran</option>
                  <option value="Al Bahah">Al Bahah</option>
                  <option value="Al-Qasim">Al-Qasim</option>
                  <option value="Jouf">Jouf</option>
                  <option value="Aseer">Aseer</option>
                </select>
              </h4>
            </center>
          </p>
        </div>

        <div class="col">
          <p>
            <center>
              <label for="triptype">
                <h4><b>trip type:</b></h4>
              </label><br>
              <h4>
                <select id="triptype" name="triptype" >
                  <option value=" ">--Select--</option>
                  <option value="Long">Long</option>
                  <option value="Short">Short</option>
                </select>
              </h4>
            </center>
          </p>
        </div>

        <div class="col">
          <p>
          <h4>
            <center>
              <label for="date">
                <h4><b>date:</b></h4>
              </label><br>
              <input type="date" id="date" name="date" >
            </center>
          </h4>
          </p>
        </div>

        <div class="col">
          <center>
          <h3><input type="submit" class="btn btn-primary pl-4 pr-4" name="submitall" value="All"></h3>
            <h3><input type="submit" class="btn btn-primary pl-4 pr-4" name="find" value="Find"></h3>
            <h3><input type="reset" class="btn btn-warning  pl-3 pr-3" value="Reset"></h3>
          </center>
        </div>
      </div>
      <hr>

    </div>
  </form>

  <h2><center>Available schedules: </center></h2>

  
<div class="container py-3">

<div class="row mt-3">
  <?php //WHERE 
  //$retrive ="SELECT * FROM created_schedules2  "; // date grater than today - ORDER BY category AND pickuptime
  
  if(isset($_POST['find'])){
    $category = $_POST['category'];
    $city = $_POST['city'];
    $triptype = $_POST['triptype'];
    $date = $_POST['date'];

    $retrive = "SELECT * FROM created_schedules2 WHERE status = 'available' AND category = '$category' AND city = '$city' AND triptype = '$triptype' AND date = '$date'";
    $serch =mysqli_query($conn,$retrive);
  } elseif (isset($_POST['submitall'])) {
    $retrive ="SELECT * FROM created_schedules2 WHERE status = 'available' AND NOT category='Delivery vans'";
    $serch =mysqli_query($conn,$retrive);
  } else {
      $retrive ="SELECT * FROM created_schedules2 WHERE status = 'available' AND NOT category='Delivery vans'";
   $serch =mysqli_query($conn,$retrive);
  }


  $check_schduals = mysqli_num_rows($serch) > 0;

  if ($check_schduals) {
    while ($row = mysqli_fetch_assoc($serch))
       {
?>
  <div class="col-md-3 mt-3">
    <div class="card ">
    <img src="go to.jpg" class="card-img-top" height="150px" width="150px" alt="Picture">
      <div style="background-color:#f2f2f2;" class="card-body ">
     <input type="hidden" name="id" value="<?php //echo $row['Rid']; ?>">
        <h3 class="card-title"><?php  echo $row['category']; ?></h3>
        <?php
        echo '<center>';
        ?>
<div class="row">
<div class="col-1">
  <br>
  </div>  
<div class="col-1">
  <p><i class="fas fa-calendar-alt "></i></i><br></p>
  <p><i class="far fa-clock x"></i></p>
  <p><i class="fas fa-clock "></i></p>
  <p><i class="fas fa-globe-americas "></i></p>
  <p><i class="fas fa-hourglass-half"></i></p>
  </div>
  <div class="col text-left">
          <p class="card-text ">Date: <?php  echo  $row['date']; ?></p>
        <p class="card-text ">Pick up time: <?php  echo $row['pickuptime']; ?></p>
        <p class="card-text ">Drop off time: <?php  echo $row['dropofftime']; ?></p>
        <p class="card-text ">City: <?php  echo $row['city']; ?></p>
        <p class="card-text ">Trip type: <?php  echo $row['triptype']; ?></p>   
    </div>
</div>




        <p class="card-text text-center text-muted"><hr><i class="fas fa-money-bill-wave"></i> Price <?php  echo $row['price']; ?> SR</p>
        <?php
        echo '</center>';
        ?>

        <div class="container">
<center><button type="button" name="container" class="btn btn-primary py-0 px-2" data-bs-toggle="modal" data-bs-target ="#myModal">Reserve</button></center> 

<div class="modal" id="myModal">
<div class="modal-dialog" >
<div class="modal-content">


<div class="modal-header">
  <h5 class="modal-title">Reservation locations</h5>
  <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body">
<form action="reserve_handle.php" method="POST" id="form1" >

<input type="hidden" name="id" value="<?php //echo $_SESSION['id']; ?>">
<input type="hidden" name="Rid" value="<?php echo $row['Rid']; ?>">


<div class="mb-3">
  <label class="form-label">Pick up location:</label>
  <input type="text" class="form-control" name="pickuplocation" placeholder=" Airport name OR District, Street, building number." required>
</div>
<div class="mb-3">
<label class="form-label">Drop off location: </label>
  <input type="text" class="form-control" name="dropofflocation" placeholder=" Airport name OR District, Street, building number." required>
</div>


</form>
</div>

<div class="modal-footer">
<button type="submit" form="form1" name="reserve" class="btn btn-primary">Submit</button>
<button type="reset" class="btn btn-warning">Reset</button>

</div>
</div>

</div>

</div>
</div>
        

        
      </div>
    </div>
  </div>
<?php
      }

  }  
  else {
    echo "No matching schedules";
  }

  ?>

</div>



  </div>

  <div style="background-color:#96A5D4;color:#ffffff;" class="row">
      
      <div class="col">        
      <br>                        
      </div>

  </div>



  </main>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
    crossorigin="anonymous"></script>

  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
  integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js"
  integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js"
  integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>

<!--

  <footer style="background-color:#96A5D4;">
    <hr>
    <center>
    <p>Author: Hege Refsnes<br>
    <a href="mailto:hege@example.com">hege@example.com</a></p>
  </center>
  <br>
  </footer>


<center><a class=" btn btn-primary py-0 px-2"   href="reserve_handle.php?Rid=<?//= $row['Rid']; ?>" >Reserve</a></center>
     
 reserve_handle.php 

        <a  href="????.php?Rid=<?php// echo $row["Rid"]; ?>" class=" btn btn-primary p-1" style="font-size:15px;  ">Reserve</a>


<div class="input-group mb-3">
  <input type="date" class="form-control" placeholder="write here" aria-label="write here"
    aria-describedby="button-addon2">
  <div class="input-group-append">
    <button class="btn btn-outline-secondary" type="button" id="button-addon2">Ok</button>
  </div>
</div>
-->











<?php
session_start();
include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Customer Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

  <style>
    .modal-header {
  background-color: #96A5D4;
  color: #ffffff;
}
  </style>
</head>

<body>

  <div class="container-fluid ">
    <div class="row">
      <div class="col-sm-12 p-3 bg-light text-white">
        <br>
      </div>
    </div>

    <div class="row">
      <div class="col-sm-4 p-3 bg-light text-white"></div>
      <!--  <div  class="col-sm-4 p-3 bg-warning text-white ">-->

      <div style="background-color: #94a4d4;" class="col-sm-4 p-3  text-white ">
        <center><img src="logo.png" style="width:20%;" alt="Website Logo"></center>
        <h2 class="text-warning">
          <center> Customer Login </center>
        </h2>
        <br>
        <center>
          <form action="c_login.php" method="POST">
            <label><b>Enter your email:</b></label>
            <br>
            <input type="email" placeholder="email" maxlength="50" name="email" required>
            <br><br>
            <label><b>Enter your password:</b></label>
            <br>
            <input type="password" placeholder="password" maxlength="8" name="password" required>
            <br><br>
            <input type="submit" class="btn btn-warning py-0 px-2" name = "login" value="Log in"></input>
          </form>
          
          <?php
if (isset($_SESSION['loginStatus'] )){
          echo '<center>';
          echo '<div class="text-danger">'. $_SESSION['loginStatus'] .'</div>';
          echo '</center>';
          unset($_SESSION['loginStatus']);
}
?>


<div class="container mt-1">
<button type="button" name="rResetLink" class="btn  py-0 px-2" data-bs-toggle="modal" data-bs-target ="#myModal">Forget My Password</button>

<div class="modal" id="myModal">
<div class="modal-dialog" >
<div class="modal-content">


<div class="modal-header">
  <h5 class="modal-title">Reset Password</h5>
  <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body">
<form action="paa_reset.php" method="POST" id="form1" >

<div class="mb-3">
  <label class="form-label" style="color: #000000;">Enter Your Email:</label>
  <input type="email" name="email" class="form-control" required>
</div>

</form>
</div>
<div class="modal-footer">
<button type="submit" name="resetLink" form="form1"  class="btn btn-primary">Send Reset Password Link</button>

</div>
</div>

</div>

</div>
</div>


<?php
/*
if(isset($_SESSION['resetPassStatus'])){
//  if($_SESSION['resetPassStatus'] == "Reset password link sent to your email"  ){
    echo '<br>';
    echo '<p class="text-success">'.$_SESSION['resetPassStatus'].'</p>';
//  }
unset($_SESSION['resetPassStatus']);
}
*/
?>
<?php
if (isset($_SESSION['resetPassStatus'] )){
  if($_SESSION['resetPassStatus'] == "Reset password link sent to your email"){
          echo '<center>';
          echo '<div class="text-warning">'. $_SESSION['resetPassStatus'] .'</div>';
          echo '</center>';
          //unset($_SESSION['loginStatus']);
  }elseif($_SESSION['resetPassStatus'] =="Passwerd reseted successfully"){    
          echo '<center>';
          echo '<div class="text-success">'. $_SESSION['resetPassStatus'] .'</div>';
          echo '</center>';
  } elseif (['resetPassStatus'] == "This email is not registered.") {
          echo '<center>';
          echo '<div class="text-danger">'. $_SESSION['resetPassStatus'] .'</div>';
          echo '</center>'; 
  }
    unset($_SESSION['resetPassStatus']);    

}
?>


<a class="btn  py-0 px-2" href="Registration.php">I am new here</a>
          

          <br>
          <!-------------------refuses to be linked------------------>
          <a class="btn  py-0 px-2" href="../Home.php">Home</a>
        </center>
      </div>


      <div class="col-sm-4 p-3 bg-light text-white"></div>

    </div>
  </div>
  <div class="row">
    <div class="col-sm-12 p-3 bg-light text-white">
      <br><br>
    </div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>

</html>





<?php
      /*
      if (isset($_POST['login'])) {
        $email = $_POST['email'];
        $password = $_POST['password'];
        $select = "SELECT * FROM customer WHERE email = '$email' AND password = '$password'";
        $result = mysqli_query($conn,$select);
        //  $row = mysqli_fetch_array($result);
        $row = $r -> fetch_assoc();

        if (mysqli_num_rows($r) > 0) {
          $_SESSION["email"] = $row['email'];
          $_SESSION["password"] = $row['password'];
          $_SESSION["fname"] = $row['fname'];
          $_SESSION["lname"] = $row['lname'];
          header("Location: customer_home.html");
        }else{
          $_SESSION['loginStatus'] = "Invalid Email or Password!";
          header("Location:customer_login.php");
        }
        }

        if(isset($_SESSION["email"])){
          header("Location: customer_home.html");// echo 'Welcome' . " " . $_SESSION["firstname"] . " " . $_SESSION["lastname"]
      } else {
        $_SESSION['loginStatus'] = "Invalid Email or Password!";
      }
      */
      ?>
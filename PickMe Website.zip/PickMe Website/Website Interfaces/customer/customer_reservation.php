<?php
  session_start();
  include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>My Reservations</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!--for icons-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>


  <style>
    .navbar-nav>span {
      padding-left: 400px;
      padding-right: 0px;
    }

    .size {
      font-size: 100%;
      text-align: center;

    }o

    i {
      color: #4c548c;
    }

    i:hover {
      color: #f1c232;
    }

    .card {
      margin-bottom: 20px;
    }

    .bttn {
      width: 100%;

    
      color: white;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 10px;
      cursor: pointer;
    }

    .content-table {
      border-collapse: collapse;
      margin: 25px 0;
      font-size: 0.9em;
      min-width: 400px;
      border-radius: 5px 5px 0 0;
      overflow: hidden;
    }

    .content-table thead tr {
      background-color: #4c548c;
      color: #f1c232;
      text-align: left;
      font-family: sans-serif;
      font-weight: bold;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    }

    .content-table td {
      padding: 12px 15px;

    }

    .content-table tbody tr:nth-of-type(odd) {
      background-color: #D1E3FA;
    }
  </style>
</head>

<body>
  <div class="container-fluid">
    <div style="background-color:#96A5D4;color:#ffffff;" class="row">
      <div class="col-1">
      </div>
      <div class="col">
        <br>
        <?php echo '<h5> Welcome <span class="text-warning">' . $_SESSION["fname"] .' '. $_SESSION["lname"]. ' </span>!</h5>';?>
      </div>
    </div>
  </div>

  <div style="background-color:#4c548c;" class="row">
    <div class="col-1"></div>

    <div class="col">
      <nav style="background-color:#4c548c;" class="navbar navbar-expand-sm navbar-light size">
        <a href="home.html"><img class="d-inline-block align-top" src="logo.png" width="60" height="60" /></a>

          <div class="collapse.navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a href="customer_home.php" class="nav-link" style="color:#d1d5e4">HOME</a>
              </li>
              <li class="nav-item">
                <a href="customer_info.php" class="nav-link" style="color:#d1d5e4">My Information</a>
              </li>
              <li class="nav-item">
                <a href="customer_reservation.php" class="nav-link text-warning">My Reservations</a>
              </li>
              <li class="nav-item">
                <a href="customer_feedback.php" class="nav-link" style="color:#d1d5e4">Give Feedback</a>
              </li>

              <span class="navbar-nav">
                <button type="button" style="font-size: 100%;" class="btn btn-warning"> <a style="font-size: 100%;" class="btn p-0 " href="logout.php">Log Out</a> </button>
              </span>
            </ul>
          </div>
      </nav>
    </div>
  </div>
  <!----------------------->
  <br>


  <h4 style="color:#4c548c;">
    <center>My Reservations</center>
  </h4>

  <?php
if (isset($_SESSION["statuspayment"])) {
  if($_SESSION["statuspayment"] == "You can't pay for canceled reservations"){
    echo '<center>';
    echo '<h5 class="text-secondary">'. $_SESSION['statuspayment'].'</h5>';
    echo '</center>';
  }elseif($_SESSION["statuspayment"] == "The reservation is already paid"){
    echo '<center>';
    echo '<h5 class="text-info">'. $_SESSION['statuspayment'].'</h5>';
    echo '</center>';
  }elseif($_SESSION["statuspayment"] = "Paid Successfully!"){
    echo '<center>';
    echo '<h5 class="text-success">'. $_SESSION['statuspayment'].'</h5>';
    echo '</center>';
  }
unset($_SESSION["statuspayment"]);
}
?>

  <?php
if (isset($_SESSION["cancel"])) {
  if($_SESSION["cancel"] == "The Schedule deleted successfully"){
    echo '<center>';
    echo '<h5 class="text-success">'. $_SESSION['cancel'].'</h5>';
    echo '</center>';
  }else{
    echo '<center>';
    echo '<h5 class="text-danger">'. $_SESSION['cancel'].'</h5>';
    echo '</center>';
  }
unset($_SESSION["cancel"]);
}
?>

<?php
  
      if ( isset($_SESSION['reserveStatus']) ) {

        if ( $_SESSION['reserveStatus'] == "Reserved successfully" ) {
          echo '<center>';
          echo '<h5 class="text-success">'. $_SESSION['reserveStatus'] .'</h5>';
          echo '</center>';
        }
        unset($_SESSION['reserveStatus']);
      }
      
      ?>

<div class="container">

  <div class="table-responsive"> 
    <table class="table table-hover">

    <table class="table table-striped content-table" style="width:100%">
      <thead>
        <tr>
          <th class="text-center"> ID</th>
          <th class="text-center">Date</th>
          <th class="text-left">Pick up time</th> 
             <th class="text-left">Drop off time</th>
          <th class="text-left">Pick up location</th>
          <th class="text-left">Drop off location</th>
          <th class="text-left">Driver</th>
          <th class="text-left">Driver Phone no.</th>
          <th class="text-left">price</th>
          <th class="text-left">Cancelation</th>
            <th class="text-center">Payment</th>
           <th class="text-center">Status</th>
         
         
        </tr>
      </thead>
      <!-- الصفوف التاليه تظهر بال php و SQL -->
      <tbody>
           
      <?php
$conn = mysqli_connect("localhost","root","","pickme");
if($conn-> connect_error){
die("Connection failed:".$conn-> connect_error);
}
$id=$_SESSION["id"];
$sql ="SELECT *  from reservation_details WHERE customerid='$id'  ORDER BY date,pickuptime ASC";
$result = $conn-> query($sql);

if ($result-> num_rows > 0){
    while ($row = $result-> fetch_assoc()){
echo "<tr><td>".$row["RID"]."</td><td>".$row["date"]
."</td><td>".$row["pickuptime"]."</td><td>".$row["dropofftime"]
."</td><td>".$row["pickuplocation"]."</td><td>".$row["dropofflocation"]
."</td><td>"
.$row["drivername"]."</td><td>".$row["driverno"]."</td><td>"
.$row["price"]."</td><td>";
if ( $row["status"]=='pending'){
?>
 
 <form action="cancel_reservation.php" method="POST">
  <input type="hidden" name="status" value="<?php echo $row["status"]; ?>">
  <button type="submit" class=" btn btn-danger p-1 " name="cancel" value="<?php echo $row["RID"]; ?>">
  <i style="color: #ffffff;" class="fa fa-calendar-times-o fa-2x "></i>
</button>
</form>
<?php } ?>
</td><td>

       <form action="cancel_reservation.php" method="POST">
  <input type="hidden" name="status" value="<?php echo $row["status"]; ?>">
  <?php
  if( $row["status"] == 'pending'){
    ?>
        <a href="customer_pay.php?RID=<?= $row["RID"]; ?>" class=" bttn badge bg-info">Pay</a>
<?php
  }elseif ($row["status"] == 'canceled') {
    ?>
        <p class="text-secondary text-center" >Canceled</p>

      <!--   <a href="customer_reservation.php" class=" bttn badge bg-info">Pay</a> -->
<?php
  }elseif ($row["status"] == 'paid' or 'picked up' or 'dropped off') {
    ?>
    <p class="text-primary text-center" >Paid</p>

<?php
    //$_SESSION["statuspayment"] = "The reservation is already paid";
    //unset( $_SESSION["statuspayment"]);
  }
  ?>
  </td><td>
</form>  

<?php
 if( $row["status"]=='pending'){
   echo "<span class='bttn badge p-2 bg-warning center'>Pending</span></tb>";
   echo "</td></tr>"; 



}elseif($row["status"]=='picked up'){
  echo " <span class=' bttn badge p-2 bg-success '>picked up</span></td>";
  echo "</td></tr>"; 
 
}elseif($row["status"]=='paid'){
  echo " <span class=' bttn badge p-2 bg-info'>paid</span></td>";
  echo "</td></tr>"; 
 
 
}elseif($row["status"]=='canceled'){
  echo " <span class='bttn badge p-2 bg-danger right'>canceled</span></td>";
  echo "</td></tr>"; 
 
 
 
}else{
  echo " <span class=' bttn badge p-2 bg-primary right'>Dropped off</span></td>";
}echo "</td></tr>"; 
 }
  echo "</table>"; }
$conn-> close();
    
?>

<!--
  <!-- <button type="submit" class=" bttn badge bg-info" name="pay" value="<?php //echo $row["RID"]; ?>">Pay
--->

    </table>    </table>

</div>
</div>

</body>

</html>
<?php
  session_start();
  include 'connection.php';
?>
<?php

    
if (isset($_POST['feed'])) {
    $customerid=$_POST['customerid'];
  $date = date('Y-m-d');
    $text=$_POST['text'];
   
  }
   $insert = "INSERT INTO feedback (customerid,date, text) VALUES ('$customerid','$date','$text')";
    $result = mysqli_query($conn,$insert);
   $_SESSION['feedbackstat'] = "Your feedback will appear on the home page.";
    header("Location:customer_give_feedback.php");

?>

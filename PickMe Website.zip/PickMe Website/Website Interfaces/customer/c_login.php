<?php
   session_start();
  include 'connection.php';

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password=md5($password);
    $select = "SELECT * FROM customer WHERE email = '$email' AND password = '$password'";
    $result = mysqli_query($conn, $select);
    if (mysqli_num_rows($result) == 1 ) {
        $result = mysqli_fetch_array($result);
        $_SESSION["id"] = $result['id'];
        $_SESSION["email"] = $result['email'];
        $_SESSION["password"] = $result['password'];
        $_SESSION["fname"] = $result['fname'];
        $_SESSION["lname"] = $result['lname'];
        $_SESSION["gender"] = $result['gender'];
        $_SESSION["phoneno"] = $result['phoneno'];
       
        $_SESSION["city"] = $result['city'];
        header("Location: customer_home.php");
    } else {
        $_SESSION['loginStatus'] = "Invalid Email or Password!";
        header("Location:customer_login.php");
    }

  }

?>
<?php /*
  session_start();
  include 'connection.php';

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $select = "SELECT * FROM customer WHERE email = '$email' AND password = '$password'";
    $result = mysqli_query($conn, $select);
    if (mysqli_num_rows($result) == 1 ) {
        $result = mysqli_fetch_array($result);
        $_SESSION["email"] = $result['email'];
        $_SESSION["password"] = $result['password'];
        $_SESSION["fname"] = $result['fname'];
        $_SESSION["lname"] = $result['lname'];
        header("Location: customer_home.php");
    } else {
        $_SESSION['loginStatus'] = "Invalid Email or Password!";
        header("Location:customer_login.php");
    }

  }
*/
?>
<?php

if (isset($_POST['editCustomer'])) {

  $customer_id= $_POST['customer_id'];
  $fname=$_POST['fname'];
  $lname=$_POST['lname'];
$email = $_POST['email'];
  $password=$_POST['password'];
  $phoneno=$_POST['phoneno'];
  $gender=$_POST['gender'];
   $city=$_POST['city'];
 
  


/*
 $select = "SELECT * FROM driver WHERE email = '$email'";//AND id ='$id' ?
  $result = mysqli_query($conn,$select);
*/
  $_SESSION['editCustomer'] = "Your information updated successfully";
  $hashed_password=md5($password);
  //لازم يحدث الشاحنه ولا بيقول ايرور      
  $updat = "UPDATE customer SET fname='$fname', lname='$lname',email='$email', password='$hashed_password', phoneno='$phoneno', gender='$gender', city='$city' WHERE id='$customer_id'";
  mysqli_query($conn,$updat);
  $_SESSION["fname"]=$fname;
  $_SESSION["lname"]=$lname;
  header("Location:customer_info.php");//<----      <----
}//end of big if


 



?>
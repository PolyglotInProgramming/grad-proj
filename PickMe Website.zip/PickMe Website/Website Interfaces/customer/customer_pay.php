<?php
  session_start();
  include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Payment</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!--for icons-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    .navbar-nav>span {
      padding-left: 400px;
      padding-right: 0px;
    }

    .size {
      font-size: 100%;
      text-align: center;

    }

    .card {
      margin-bottom: 20px;
    }

    input[type=text],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }
    input[type=tel],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=email],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=password],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=number],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }


    input[type=date],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    

    input[type=submit] {
      width: 100%;
      background-color: #4c548c;
      color: #f1c232;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    input[type=reset] {
      width: 100%;
      background-color: #f1c232;
      color: #4c548c;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }


    div.container {
      border-radius: 5px;
      background-color: #f2f2f2;
      padding: 20px;
    }

    #number{
      outline:0;
    }
      #number:valid{
      border-color:green;
    }
      #number:focus:invalid{
        border-color:red;
    }
  </style>
</head>

<body>
  <div class="container-fluid">
    <div style="background-color:#96A5D4;color:#ffffff;" class="row">
      <div class="col-1">
      </div>
      <div class="col">
        <br>
       <?php echo '<h5> Welcome <span class="text-warning">' . $_SESSION["fname"] .' '. $_SESSION["lname"]. ' </span>!</h5>';?>
      </div>
    </div>
  </div>

  <div style="background-color:#4c548c;" class="row">
    <div class="col-1"></div>

    <div class="col">
      <nav style="background-color:#4c548c;" class="navbar navbar-expand-sm navbar-light size">
        <a href="home.html"><img class="d-inline-block align-top" src="logo.png" width="60" height="60" /></a>

          <div class="collapse.navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a href="customer_home.html" class="nav-link" style="color:#d1d5e4">HOME</a>
              </li>
              <li class="nav-item">
                <a href="customer_info.html" class="nav-link" style="color:#d1d5e4">My Information</a>
              </li>
              <li class="nav-item">
                <a href="customer_reservation.html" class="nav-link  text-warning">My Reservations</a>
              </li>
              <li class="nav-item">
                <a href="customer_feedback.html" class="nav-link" style="color:#d1d5e4">Give Feedback</a>
              </li>

              <span class="navbar-nav">
                <button type="button" style="font-size: 100%;" class="btn btn-warning"> <a style="font-size: 100%;" class="btn p-0 " href="logout.php">Log Out</a> </button>
              </span>
            </ul>
          </div>
      </nav>
    </div>
    <?php
    /*

       .inputCard{

      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }


if(isset($_GET['pay'])){
  $reservation_id = $_GET['Rid'];

$reservation = "SELECT *  FROM reservation WHERE Rid=' $reservation_id'";
 $reservation_run = mysqli_query($conn, $reservation);
  if(mysqli_num_rows($$reservation_run) > 0){
    foreach ($reservation_run as $reservation) {
     */ ?>

  </div>
  <br>

  <?php 
  if(isset($_GET['RID'])){
    $Rid = $_GET['RID'];
 $_SESSION['RID'] = $Rid;
  }
  ?>

  <h3 class="text-center" style="color:#4c548c;">Pay for Reservation ID: <span class="text-warning"><?php echo $_SESSION['RID']; ?></span></h3>
  <div class="container">
    


  <form style="color:#4c548c;" action="cancel_reservation.php" method="post">

      <label style="color:#4c548c;" for="number">Card Number</label>
      <input type="text" id="number"  placeholder="Enter the number that contains 16 digits" maxlength="16" pattern="[0-9]{16,16}" name="cardno" required>
     
      <label style="color:#4c548c;" for="number">CVV</label>
      <input type="text" id="number" pattern="[0-9]{3,3}"  placeholder="Enter the number on your card that contains 3 digits" maxlength="3" name="cvv" required>


      <label for="EXPdate">Expiration  Date</label>
      
      <input type="date" name="EXPdate" id="expiry"  required/>

      <input type="submit" value="pay" name="pay">

      <input type="reset" value="Reset">
    </form>
  </div>
  <?php /*
    }
  } else {
      ?>
<div class="container"><center><h4>No record found</h4></center> </div>
<?php
      }
}
class="inputCard"
*/?>  
</body>

</html>
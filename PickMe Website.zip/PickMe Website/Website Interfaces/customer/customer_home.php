<?php
  session_start();
  include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Customer Home Page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!--for icons-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>

    .navbar-nav>span {
      padding-left: 400px;
      padding-right: 0px;
    }

    .size {
      font-size: 100%;
      text-align: center;

    }

    .text{
    color: #d3aa61;
    font-size: 30px;
    text-shadow: 10px 20px 30px  #a08c6c;
}


h3 {
     
    
  color: #5a6493;
}

div .but{
    position: absolute;
  right:  150px;
 
}
center a:link, a:visited {
    background-color: #5a6493;
    color: white;
    padding: 14px 25px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
  }
  
  center a:hover, a:active {
    background-color: #4c5494;
  }

    .card {
      margin-bottom: 20px;
    }

    input[type=text],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=email],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=password],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=number],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=date],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=submit] {
      width: 100%;
      background-color: #4c548c;
      color: #f1c232;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    input[type=reset] {
      width: 100%;
      background-color: #f1c232;
      color: #4c548c;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }


    div.container {
      border-radius: 5px;
      background-color: #f2f2f2;
      padding: 20px;
    }
  </style>
</head>

<body>
  <div class="container-fluid">
    <div style="background-color:#96A5D4;color:#ffffff;" class="row">
      <div class="col-1">
      </div>
      <div class="col">
        <br>
        <?php echo '<h5> Welcome <span class="text-warning">' . $_SESSION["fname"] .' '. $_SESSION["lname"]. ' </span>!</h5>';?>
      </div>
    </div>
  </div>

  <div style="background-color:#4c548c;" class="row">
    <div class="col-1"></div>

    <div class="col">
      <nav style="background-color:#4c548c;" class="navbar navbar-expand-sm navbar-light size">
        <a href="home.html"><img class="d-inline-block align-top" src="logo.png" width="60" height="60" /></a>
            <div class="collapse.navbar-collapse" id="navbarNav">
              <ul class="navbar-nav">
                <li class="nav-item">
                  <a href="customer_home.php" class="nav-link text-warning">HOME</a>
                </li>
                <li class="nav-item">
                  <a href="customer_info.php" class="nav-link" style="color:#d1d5e4">My Information</a>
                </li>
                <li class="nav-item">
                  <a href="customer_reservation.php" class="nav-link " style="color:#d1d5e4">My Reservations</a>
                </li>
                <li class="nav-item">
                  <a href="customer_feedback.php" class="nav-link" style="color:#d1d5e4">Give Feedback</a>
                </li>

                <span class="navbar-nav">
                  <button type="button" style="font-size: 100%;" class="btn btn-warning"> <a style="font-size: 100%;" class="btn p-0 " href="logout.php">Log Out</a> </button>
                </span>
              </ul>
            </div>
      </nav>
    </div>
  </div>

    <br>
    <h3 style="text-align: center;">Welcome To Pick Me System</h3>
    <br>

    <hr style="height: 1px; margin: 0px; border-top: 0px; padding: 0px; background: linear-gradient(to right, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.75),
    rgba(0, 0, 0, 0));">

  <div class="row">
    <div class="col-sm-1 p-4 bg-light "></div>

    <div class="col-sm-5 p-4 bg-light ">
      <br><br>
      <img src="car5.png" alt="picture" width="100%" height="90%" class="picture">
    </div>

    <div class="col-sm-5 p-4  bg-light ">
      <br><br>
      <div class="text"> Don't be late!</div>
      <h3>We are here to serve you. </h3>
      <br>
      <center><a href="reservation/Reserve.html" target="_blank" class="link">Let's Start!</a></center>

    </div>

    <div class="col-sm-1 p-4 bg-light "></div>

  </div>

</body>

</html>
<?php
  session_start();

  include 'connection.php';




// delete schedule
if (isset($_POST['editsch'])) { 
  $Rid= $_POST['Rid'];
  $status= $_POST['status'];
      $date = $_POST['date'];
      $dropofftime= $_POST['dropofftime'];
      $pickuptime = $_POST['pickuptime'];
      $id = $_POST['id'];

      $select1 ="SELECT driverid, date,pickuptime, dropofftime FROM reservation_details where (driverid='$id' AND date='$date') AND pickuptime='$pickuptime' AND dropofftime='$dropofftime'";
      $select2 ="SELECT driverid, date,pickuptime, dropofftime FROM reservation_details where (driverid='$id' AND date='$date') AND pickuptime BETWEEN '$pickuptime' AND '$dropofftime'";
      $result1 = mysqli_query($conn, $select1);
      $result2 = mysqli_query($conn, $select2);
  // check if date in the future or not
  
     
  $todydate = date('Y-m-d');
  // convert to strotime
  $str_res = strtotime($date); 
  $str_todydate = strtotime($todydate); 
  // compare
  if($str_res < $str_todydate){
    $_SESSION['upDate'] ="The date cannot be in the past";
    header("Location:updatesche.php?Rid=$Rid");
  }else {
  
  
  
  
   if (mysqli_num_rows($result1) || mysqli_num_rows($result2) > 0 ){
      $_SESSION["updateScheduleStatus"] = "Driver already assigned to schedule at the specified time";
      header("Location:updatesche.php?Rid=$Rid");
  
        
      }else{
     

 if ($status  == 'available'){ 
  //delete 
  $q = "UPDATE reservation SET date='$date', dropofftime='$dropofftime',pickuptime='$pickuptime' WHERE Rid='$Rid'";
  $r = mysqli_query($conn,$q);
    //
    
        $_SESSION["editsch"] = "The Schedule edited successfully";
        header("Location:organize_schedule.php");
    }
  }
  }}
  
  //end of big if  
?>




<?php
/*
    if(mysqli_num_rows($s) == 0) {
    echo '<option value=""> No suitable drivers </option>'; 
    }elseif(mysqli_num_rows($s) > 0){
    echo '<option value="">id driver</option>';  
    } 
*/


/*
if (isset($_GET['findDriver'])) {
    $triptype = $_GET['triptype'];
    $city = $_GET['city'];
    $category = $_GET['category'];

    //$con = mysqli_connect('localhost','root','','pickme');
    $s=mysqli_query($conn,"SELECT id, fname FROM suitable_drivers WHERE city ='$city' AND triptype='$triptype' AND category='$category'");
    $r = mysqli_fetch_array($s);
    header("Location:add_schedule.php");

    }
    */
?> 



<?php 
/*
<select style="color:gray;" name="driverid" required>
    <option  value="">id driver</option>
    <?php
    while($r)
   { ?>
    <option value="<?php echo $r['id'];?>"> <?php echo $r['id']." ".$r['fname'];?> </option> 
    <?php    
   }
   ?>
    </select>
*/ 
?>

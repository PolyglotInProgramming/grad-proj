<?php
  session_start();
  include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>add Vehicle</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!--for icons-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    .navbar-nav>span {
      padding-left: 30px;
      padding-right: 0px;
    }

    .size {
      font-size: 100%;
      text-align: center;

    }

    .card {
      margin-bottom: 20px;
    }

    input[type=text],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=email],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=password],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=number],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=date],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=submit] {
      width: 100%;
      background-color: #4c548c;
      color: #f1c232;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    input[type=reset] {
      width: 100%;
      background-color: #f1c232;
      color: #4c548c;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }


    div.container {
      border-radius: 5px;
      background-color: #f2f2f2;
      padding: 20px;
    }

    #n:focus{
      outline: 0;
    }
    #n:valid{
      border-color: green;
    }
    #n:focus:invalid{
      border-color: red;
    }

    #p:focus{
      outline: 0;
    }
    #p:valid{
      border-color: green;
    }
    #p:focus:invalid{
      border-color: red;
    }


  </style>
</head>

<body>
  <div class="container-fluid">
    <div style="background-color:#96A5D4;color:#ffffff;" class="row">
      <div class="col-1">
      </div>
      <div class="col">
        <br>
        <?php echo '<h5> Welcome <span class="text-warning">' . $_SESSION["fname"] .' '. $_SESSION["lname"]. ' </span>!</h5>';?>
      </div>
    </div>
  </div>

  <div style="background-color:#4c548c;" class="row">
    <div class="col-1"></div>

    <div class="col">

    <nav style="background-color:#4c548c;" class="navbar navbar-expand-sm navbar-light size">
                    <a href="مها#"><img class="d-inline-block align-top" src="logo.png" width="60" height="60" /></a>
                    <div class="collapse.navbar-collapse" id="navbarNav" >
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a href="Dashboard.php" class="nav-link " style="color:#d1d5e4">
                                    DASHBOARD
                                </a>
                            </li>
                           
                            <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle  text-warning" style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                  Manage Vehicles
                                </a>
                                <ul class="dropdown-menu "  >
                                  <li><a class="dropdown-item bg-warning " style="color:#4c548c;" href="add_vehicle.php">Add Vehicle</a></li> 
                                  <li><a class="dropdown-item "  style="color:#4c548c;" href="vehicles_table.php">View Vehicles</a></li> 
                                  <li><a class="dropdown-item"  style="color:#4c548c;" href=" assigned_vehicles.php ">View assigned Vehicles</a></li> 
                                </ul>
                              </li>

                              <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle " style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Manage Drivers
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="add_driver.php">Add Driver</a></li> 
                                    <li><a class="dropdown-item"  style="color:#4c548c;" href="admin_view_driver.php">View Drivers</a></li> 
                                </ul>
                              </li>



                              <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle " style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Manage Reservations
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                <li><a class="dropdown-item " style="color:#4c548c;" href="add_schedule_findD.php">Organize Schedule</a></li> 
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="organize_schedule.php">Created Schedules</a></li> 
                                    <li><a class="dropdown-item "  style="color:#4c548c;" href="admin_view_reservations.php">View Reservations</a></li>
                                </ul>
                              </li>  
                                                            

                              <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle" style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Customers
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="admin_view_customer.php">View Customers</a></li> 
                                    <li><a class="dropdown-item " style="color:#4c548c;"  href="admin_view_feedback.php">View Feedbacks</a></li>                                </ul>
                              </li> 

                            <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle " style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Announcements
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="admin_send_annunc.php	">Send Announcement</a></li> 
                                    <li><a class="dropdown-item"  style="color:#4c548c;" href="admin_annuncment.php">Sent Announcements</a></li> 
                                </ul>
                              </li> 


                            <span class="navbar-nav">
                                <button type="button" style="font-size: 100%;" class="btn btn-warning"> <a
                                        style="font-size: 100%;" class="btn p-0 " href="logout.php">Log Out</a>
                                </button>
                            </span>
                        </ul>
                    </div>
                </nav>
    
    </div>
  </div>
  <br>
  <h3 class="text-center" style="color:#4c548c;">Add New Vehicle</h3>
  <div class="container">
    <form style="color:#4c548c;" action="vehicleinfo.php" method="POST">

      <label style="color:#4c548c;">Vehicle name</label>
      <input type="text" id="n" pattern="[A-Za-z\s]{3,30}" maxlength="30" placeholder="vehicle name" name="vehiclename">
      <?php

    if(isset($_SESSION['regesterStatus'])){
    if($_SESSION['regesterStatus'] == "Vehicle plate already exists."){


 
     echo '<center>';
     echo '<h5 class="text-danger">'. $_SESSION['regesterStatus'].'</h5>';
     echo '</center>';

    
      }else if( $_SESSION['regesterStatus'] == "Vehicle added successfully"){
        echo '<center>';
        echo '<h5 class="text-success">'. $_SESSION['regesterStatus'].'</h5>';
        echo '</center>';

     }  
     unset($_SESSION['regesterStatus']);}
        
           ?>

      <label style="color:#4c548c;" for="lname">Vehicle plate </label>
      <input type="text" id="p" name="vehicleplate" pattern="[a-zA-Z0-9]{7}"  maxlength="7" placeholder="eg.ABC123" required>
<!--"-->

      <label style="color:#4c548c;" for="Category">Category</label>
      <select id="Category" name="category">
      <option value=" "> --Select--</option>
        <option value="Delivery vans"> Delivery vans</option>
        <option value="Standard">Standard</option>
        <option value="express"> express</option>
        <option value="First class">First class</option>
      </select>



      </select>
      <label for="Vehicleyear">Vehicle year</label>
      <!--<input type="text" id="Vyear" name="vehicleyear">-->
      <select id="Vyear" name="vehicleyear">
      <option value=" ">--Select--</option>
      <?php
        for ($y = 2016; $y <= 2023; $y++) {
        echo'<option value="'. $y .' ">'. $y .'</option>';;
        }
      ?>
         
      </select>

      <label style="color:#4c548c;">Admin ID</label>

        <input type="text" name="added_adminid"value="<?php  echo $_SESSION['id'];?>">
    
      <input type="submit" name="submit" value="Add Vehicle">
      <input type="reset" value="Reset">
    </form>
  </div>


</body>

</html>
<?php
  session_start();
  include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Send Announcement</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!--for icons-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    .navbar-nav>span {
      padding-left: 30px;
      padding-right: 0px;
    }

    .size {
      font-size: 100%;
      text-align: center;

    }

    .card {
      margin-bottom: 20px;
    }

    input[type=text],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }



    input[type=password],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }



    input[type=date],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=submit] {
      width: 100%;
      background-color: #4c548c;
      color: #f1c232;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    textarea {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=reset] {
      width: 100%;
      background-color: #f1c232;
      color: #4c548c;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }


    div.container {
      border-radius: 5px;
      background-color: #f2f2f2;
      padding: 20px;
    }
  </style>
</head>

<body>
  <div class="container-fluid">
    <div style="background-color:#96A5D4;color:#ffffff;" class="row">
      <div class="col-1">
      </div>
      <div class="col">
        <br>
        <?php echo '<h5> Welcome <span class="text-warning">' . $_SESSION["fname"] .' '. $_SESSION["lname"]. ' </span>!</h5>';?>
      </div>
    </div>
  </div>

  <div style="background-color:#4c548c;" class="row">
    <div class="col-1"></div>

    <div class="col">

    <nav style="background-color:#4c548c;" class="navbar navbar-expand-sm navbar-light size">
                    <a href="مها#"><img class="d-inline-block align-top" src="logo.png" width="60" height="60" /></a>
                    <div class="collapse.navbar-collapse" id="navbarNav" >
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a href="Dashboard.php" class="nav-link " style="color:#d1d5e4">
                                    DASHBOARD
                                </a>
                            </li>
                           
                            <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle " style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                  Manage Vehicles
                                </a>
                                <ul class="dropdown-menu "  >
                                  <li><a class="dropdown-item " style="color:#4c548c;" href="add_vehicle.php">Add Vehicle</a></li> 
                                  <li><a class="dropdown-item "  style="color:#4c548c;" href="vehicles_table.php">View Vehicles</a></li> 
                                  <li><a class="dropdown-item"  style="color:#4c548c;" href=" #### ">View assigned Vehicles</a></li> 
                                </ul>
                              </li>

                              <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle " style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Manage Drivers
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="add_driver.php">Add Driver</a></li> 
                                    <li><a class="dropdown-item"  style="color:#4c548c;" href="drivers_table.php">View Drivers</a></li> 
                                </ul>
                              </li>



                              <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle " style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Manage Reservations
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                <li><a class="dropdown-item " style="color:#4c548c;" href="add_schedule_findD.php">Organize Schedule</a></li> 
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="organize_schedule.php">Created Schedules</a></li> 
                                    <li><a class="dropdown-item "  style="color:#4c548c;" href="admin_view_reservations.php">View Reservations</a></li>
                                </ul>
                              </li>  
                                                            

                              <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle" style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Customers
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="admin_view_customer.php">View Customers</a></li> 
                                    <li><a class="dropdown-item " style="color:#4c548c;"  href="admin_view_feedback.php">View Feedbacks</a></li>                                </ul>
                              </li> 

                            <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle  text-warning" style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Announcements
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                    <li><a class="dropdown-item bg-warning " style="color:#4c548c;" href="admin_send_annunc.php	">Send Announcement</a></li> 
                                    <li><a class="dropdown-item"  style="color:#4c548c;" href="admin_annuncment.php">Sent Announcements</a></li> 
                                </ul>
                              </li> 


                            <span class="navbar-nav">
                                <button type="button" style="font-size: 100%;" class="btn btn-warning"> <a
                                        style="font-size: 100%;" class="btn p-0 " href="logout.php">Log Out</a>
                                </button>
                            </span>
                        </ul>
                    </div>
                </nav>

    </div>
  </div>
  <br>
  <h3 class="text-center" style="color:#4c548c;">Send New Announcement</h3>
  <div class="container">
 <?php
 if(isset($_SESSION['announcStatus'])){
 if($_SESSION['announcStatus'] == "Annoucement sent successfully."){
 echo  '<h5 class="text-success">'.$_SESSION['announcStatus']."</h5>";
 $_SESSION['announcStatus']="";
/* unset($_SESSION['announcStatus']);}*/
 }}
 ?>
    <form style="color:#4c548c;" action="annou.php" method="POST">
      <label style="color:#4c548c;" for="annunc">Enter Your Message</label><br>
      <span class=" text-warning"> *Announcements are sent to all drivers</span>
      <textarea name="text" id="annunc" cols="169" rows="5" required></textarea>
      <label style="color:#4c548c;">Admin ID</label>
   <input type="text" name="added_adminid"value="<?php  echo $_SESSION['id'];?>">
        
      <input type="submit" name="submit" value="Send Announcement">
      <input type="reset" value="Reset">
      
    </form>
  </div>


</body>

</html>
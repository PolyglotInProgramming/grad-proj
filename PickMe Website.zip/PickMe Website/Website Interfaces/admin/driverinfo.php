 

<?php
session_start();
include('connection.php');

// adding driver
if (isset($_POST['submit'])) {
    $fname=$_POST['fname'];
    $lname=$_POST['lname'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $phoneno=$_POST['phoneno'];
    $city=$_POST['city'];
    $triptype=$_POST['triptype'];
    $lictype=$_POST['lictype'];
    $licexp=$_POST['licexp'];
    $vehicleid=$_POST['vehicleid'];
    $added_adminid=$_POST['added_adminid'];

// check if date in the future or not
$todydate = date('Y-m-d');
// convert to strotime
$str_licexp = strtotime($licexp); 
$str_todydate = strtotime($todydate); 
// compare
if($str_licexp < $str_todydate){
  $_SESSION['licexpStatus'] ="The date cannot be in the past";
  header("Location:add_driver.php");

}else{

   $select = "SELECT * FROM driver WHERE email = '$email'";
    $result = mysqli_query($conn,$select);
 
    if (mysqli_num_rows($result) > 0) {
    $_SESSION['regesterStatus'] = "Email already exists.";
    header("Location:add_driver.php");
   } else {
    $_SESSION['regesterStatus'] = "Driver registered successfully";
    $hashed_password=md5($password);
    $registr = "INSERT INTO driver (fname, lname, email, password, phoneno, city, triptype, lictype, licexp, vehicleid, added_adminid) VALUES ('$fname','$lname','$email','$hashed_password','$phoneno','$city','$triptype','$lictype','$licexp','$vehicleid','$added_adminid')";
    mysqli_query($conn,$registr);
    //$_SESSION['regesterStatus'] = "Driver registered sucessfully.";
    header("Location:add_driver.php");
}

}

}

 
// updating driver
//////// تعديل \\\\\\\\
if (isset($_POST['editDriver'])) {

    $driver_id= $_POST['driver_id'];
    $fname=$_POST['fname'];
    $lname=$_POST['lname'];
  $email = $_POST['email'];
    $password=$_POST['password'];
    $phoneno=$_POST['phoneno'];
    $city=$_POST['city'];
    $triptype=$_POST['triptype'];
    $lictype=$_POST['lictype'];
    $licexp=$_POST['licexp'];
  
    
    $added_adminid=$_POST['added_adminid'];
  
// check if date in the future or not
$todydate = date('Y-m-d');
// convert to strotime
$str_licexp = strtotime($licexp); 
$str_todydate = strtotime($todydate); 
// compare
if($str_licexp < $str_todydate){
  $_SESSION['licexpStatus'] ="The date cannot be in the past";
  header("Location:update_driver_form.php?id=$driver_id");//<----    true
  
}else{
/*
   $select = "SELECT * FROM driver WHERE email = '$email'";//AND id ='$id' ?
    $result = mysqli_query($conn,$select);
*/
    $_SESSION['editDriverStatus'] = "Driver information updated successfully";
    $hashed_password=md5($password);
    //لازم يحدث الشاحنه ولا بيقول ايرور      
    $update = "UPDATE driver SET fname='$fname', lname='$lname',email='$email', password='$hashed_password', phoneno='$phoneno', city='$city', triptype='$triptype', lictype='$lictype', licexp='$licexp', added_adminid='$added_adminid' WHERE id='$driver_id'";
    mysqli_query($conn,$update);
    header("Location:admin_view_driver.php");//<----      <----
}

  
  }//end of big if 

/*
,,',,,,,,,,

*/


/*
    if (mysqli_num_rows($result) > 0) {// ممكن ما يغير الايميل و هو بالاساس ما تسجل الاواحد    <----
    $_SESSION['editDriverStatus'] = "Email already registered.";
    header("Location:update_driver_form.php?id=");//<----    true
   } else {
*/ 
    /*
    //check email not repeted
    $select = "SELECT * FROM driver WHERE email = '$email'";
    $result = mysqli_query($conn,$select);
      if (mysqli_num_rows($result) > 0) {
    $_SESSION['editDriverStatus'] = "Email already registered.";
    header("Location:update_driver_form.php");
  } else {
      //update 
    $update = "INSERT INTO customer (fname,lname,email, password, phonenum,city, trip, lictype, licexp ) VALUES ('$fname','$lname','$email','$password','$phoneno','$city','$trip','$lictype','$licexp')";
    mysqli_query($conn,$update);
    $_SESSION["editDriverStatus"] = "Driver information updated successfully";
    header("Location:admin_view_driver.php");
  
  }
  */
  
/*
if(isset($_POST['submit'])){
    $fname=$_POST['fname'];
    $lname=$_POST['lname'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $phoneno=$_POST['phoneno'];
    $city=$_POST['city'];
    $triptype=$_POST['triptype'];
    $lictype=$_POST['lictype'];
    $licexp=$_POST['licexp'];
    $vehicleid=$_POST['vehicleid'];
    $added_adminid=$_POST['added_adminid'];
    }
    
$sql="INSERT INTO driver (fname, lname, email, password, phoneno, city, triptype, lictype, licexp, vehicleid, added_adminid) VALUES ('$fname','$lname','$email','$password','$phoneno','$city','$triptype','$lictype','$licexp','$vehicleid','$added_adminid')";
mysqli_query($conn,$sql);

header("Location:admin_view_driver.php");
?>*/
?>

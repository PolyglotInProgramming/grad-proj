<?php
  session_start();
  include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>edit driver</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!--for icons-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

  <style>
    #fn:focus{
      outline: 0;
    }
    #fn:valid{
      border-color: green;
    }
    #fn:focus:invalid{
      border-color: red;
    }
    #ln:focus{
      outline: 0;
    }
    #ln:valid{
      border-color: green;
    }
    #ln:focus:invalid{
      border-color: red;
    }
    .navbar-nav>span {
      padding-left: 30px;
      padding-right: 0px;
    }

    .size {
      font-size: 100%;
      text-align: center;

    }

    .card {
      margin-bottom: 20px;
    }

    input[type=text],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
      background-color: white;
    }

    input[type=email],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=password],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=tel],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=date],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type=submit] {
      width: 100%;
      background-color: #4c548c;
      color: #f1c232;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    input[type=reset] {
      width: 100%;
      background-color: #f1c232;
      color: #4c548c;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }


    div.container {
      border-radius: 5px;
      background-color: #f2f2f2;
      padding: 20px;
    }
    #number{
      outline:0;
    }
      #number:valid{
      border-color:green;
    }
      #number:focus:invalid{
        border-color:red;
    }
    
  </style>
</head>

<body>
  <div class="container-fluid">
    <div style="background-color:#96A5D4;color:#ffffff;" class="row">
      <div class="col-1">
      </div>
      <div class="col">
        <br>
        <?php echo '<h5> Welcome <span class="text-warning">' . $_SESSION["fname"] .' '. $_SESSION["lname"].' </span>'.'</span> !</h5>';?>
      </div>
    </div>
  </div>

  <div style="background-color:#4c548c;" class="row">
    <div class="col-1"></div>

    <div class="col">
    <nav style="background-color:#4c548c;" class="navbar navbar-expand-sm navbar-light size">
                    <a href="مها#"><img class="d-inline-block align-top" src="logo.png" width="60" height="60" /></a>
                    <div class="collapse.navbar-collapse" id="navbarNav" >
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a href="Dashboard.php" style="color:#d1d5e4" class="nav-link">
                                    DASHBOARD
                                </a>
                            </li>
                           
                            <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle " style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                  Manage Vehicles
                                </a>
                                <ul class="dropdown-menu "  >
                                  <li><a class="dropdown-item " style="color:#4c548c;" href="add_vehicle.php">Add Vehicle</a></li> 
                                  <li><a class="dropdown-item"  style="color:#4c548c;" href="vehicles_table.php">View Vehicles</a></li> 
                                  <li><a class="dropdown-item"  style="color:#4c548c;" href="assigned_vehicles.php">View assigned Vehicles</a></li> 
                                </ul>
                              </li>

                              <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle text-warning" style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Manage Drivers
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="add_driver.php">Add Driver</a></li> 
                                    <li><a class="dropdown-item bg-warning"  style="color:#4c548c;" href="admin_view_driver.php">View Drivers</a></li> 
                                </ul>
                              </li>



                              <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle " style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Manage Reservations
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                <li><a class="dropdown-item " style="color:#4c548c;" href="add_schedule_findD.php">Organize Schedule</a></li> 
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="organize_schedule.php">Created Schedules</a></li> 
                                    <li><a class="dropdown-item "  style="color:#4c548c;" href="admin_view_reservations.php">View Reservations</a></li>
                                </ul>
                              </li>  
                                                            

                              <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle" style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Customers
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="admin_view_customer.php">View Customers</a></li> 
                                    <li><a class="dropdown-item " style="color:#4c548c;"  href="admin_view_feedback.php">View Feedbacks</a></li>                                </ul>
                              </li> 

                            <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle " style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Announcements
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="admin_send_annunc.php	">Send Announcement</a></li> 
                                    <li><a class="dropdown-item"  style="color:#4c548c;" href="admin_annuncment.php">Sent Announcements</a></li> 
                                </ul>
                              </li> 



                            <span class="navbar-nav">
                                <button type="button" style="font-size: 100%;" class="btn btn-warning"> <a
                                        style="font-size: 100%;" class="btn p-0 " href="logout.php">Log Out</a>
                                </button>
                            </span>
                        </ul>
                    </div>
                </nav>
    </div>
  </div>
  <br>
  <h3 class="text-center" style="color:#4c548c;">Edit Driver</h3>

      <?php
if(isset($_GET['id'])){
  $driver_id = $_GET['id'];

$drivers = "SELECT *  FROM driver WHERE id='$driver_id'";
$driver_run = mysqli_query($conn, $drivers);
  if(mysqli_num_rows($driver_run) > 0){
    foreach ($driver_run as $driver) {
      ?>


  <div class="container">
    <form style="color:#4c548c;" action="driverinfo.php" method="POST">

    <input type="hidden" name="driver_id" value="<?=$driver['id']; ?>" >
      <label style="color:#4c548c;" for="fn">Driver's first name</label>
      <input type="text" pattern="[A-Za-z\s]{3,30}" maxlength="50" id="fn" name="fname" value="<?=$driver['fname']; ?>"  >

      <label style="color:#4c548c;" for="ln">Driver's last name</label>
      <input type="text" pattern="[A-Za-z\s]{3,30}" maxlength="50" id="ln" name="lname" value="<?=$driver['lname']; ?>"  >

      <?php
/*
if(isset($_SESSION['editDriverStatus'])){
  if ($_SESSION['editDriverStatus'] == "Email already registered.") {
    echo '<center>';
    echo '<h5 class="text-danger">' . $_SESSION['editDriverStatus'] . '</h5>';
    echo '</center>';
  }
     unset($_SESSION['editDriverStatus']);
}
 */       
           ?>

      <label style="color:#4c548c;" for="email">Driver's email</label>
      <input type="email" size="50" id=" email" name="email" value="<?=$driver['email']; ?>"  disabled>
      <input type="hidden" size="50" id=" email" name="email" value="<?=$driver['email']; ?>" >

      <label style="color:#4c548c;" for="passsword">Driver's password</label>
      <input type="password" id="passwords" name="password" maxlength="8"  >

      <label style="color:#4c548c;" for="number">Driver's Phone number</label>
      <input type="tel" id="number" name="phoneno" value="<?=$driver['phoneno']; ?>"  placeholder="05xx-xxx-xxx" pattern="[0-9]{4}-[0-9]{3}-[0-9]{3}"  >


      <label style="color:#4c548c" for="city">City</label>
      <select id="City" name="city"  >
      <option value=" ">--Select--</option> 
        <option value="Riyadh" <?=$driver['city'] == 'Riyadh' ? 'selected' : '' ?>>Riyadh</option>
        <option value="Dammam" <?=$driver['city'] == 'Dammam' ? 'selected' : '' ?>>Dammam</option>
        <option value="Jeddah" <?=$driver['city'] == 'Jeddah' ? 'selected' : '' ?>>Jeddah</option>
        <option value="Medina" <?=$driver['city'] == 'Medina' ? 'selected' : '' ?>>Medina</option>
        <option value="Mecca" <?=$driver['city'] == 'Mecca' ? 'selected' : '' ?>>Mecca</option>
        <option value="Taif" <?=$driver['city'] == 'Taif' ? 'selected' : '' ?>>Taif</option>
        <option value="Al-Ahsa" <?=$driver['city'] == 'Al-Ahsa' ? 'selected' : '' ?>>Al-Ahsa</option>
        <option value="Hafar Al Batin" <?=$driver['city'] == 'Hafar Al Batin' ? 'selected' : '' ?>>Hafar Al Batin</option>
        <option value="Hail" <?=$driver['city'] == 'Hail' ? 'selected' : '' ?>>Hail</option>
        <option value="Tabuk" <?=$driver['city'] == 'Tabuk' ? 'selected' : '' ?>>Tabuk</option>
        <option value="Arar" <?=$driver['city'] == 'Arar' ? 'selected' : '' ?>>Arar</option>
        <option value="Jazan" <?=$driver['city'] == 'Jazan' ? 'selected' : '' ?>>Jazan</option>
        <option value="Najran" <?=$driver['city'] == 'Najran' ? 'selected' : '' ?>>Najran</option>
        <option value="Al Bahah" <?=$driver['city'] == 'Al Bahah' ? 'selected' : '' ?>>Al Bahah</option>
        <option value="Al-Qasim" <?=$driver['city'] == 'Al-Qasim' ? 'selected' : '' ?>>Al-Qasim</option>
        <option value="Jouf" <?=$driver['city'] == 'Jouf' ? 'selected' : '' ?>>Jouf</option>
        <option value="Aseer" <?=$driver['city'] == 'Aseer' ? 'selected' : '' ?>>Aseer</option>
      </select>

      <label style="color:#4c548c;" for="triptype">Trip Type</label>
      <select id="Trip" name="triptype"  >
      <option value=" ">--Select--</option>
        <option value="Long" <?=$driver['triptype'] == 'Long' ? 'selected' : '' ?>>Long</option>
        <option value="Short" <?=$driver['triptype'] == 'Short' ? 'selected' : '' ?>>Short</option>
      </select>

      <label style="color:#4c548c;" for="licence type">licence type</label>
      <select id="licence" name="lictype"  >
      <option value=" ">--Select--</option>
        <option value="Publick driving licence" <?=$driver['lictype'] == 'Publick driving licence' ? 'selected' : '' ?>>Publick driving licence</option>
        <option value="Heavy Driving License"<?=$driver['lictype'] == 'Heavy Driving License' ? 'selected' : '' ?>>Heavy Driving License</option>
      </select>

      <label for="driving_licencesEXP">licences expiration date</label>

      <?php
      
      if(isset($_SESSION['licexpStatus'])){

        if( $_SESSION['licexpStatus'] == "The date cannot be in the past"){
      echo '<p class="text-danger">'. $_SESSION['licexpStatus'].'</p>';
      //unset($_SESSION['licexpStatus']);
      /*}else if($_SESSION['licexpStatus'] == "Email already registered."){
      
      */}
      unset($_SESSION['licexpStatus']);
      }
      
      ?>

      <input type="date" id="licenceEXP" name="licexp" value="<?=$driver['licexp']; ?>"   >
      
     
 

      <?php /*
$con = mysqli_connect('localhost','root','','pickme');
    $s=mysqli_query($con,"SELECT vehicle.id, vehicle.vehiclename FROM vehicle WHERE NOT EXISTS ( SELECT vehicleid FROM driver WHERE driver.vehicleid =vehicle.id )");
      
        //لازم يحدث الشاحنه ولا بيقول ايرور      
        // مو راضي يطلع المدخل 
/*
حل : ممكن نخلي تحديث السائق فقط معلوماته اما تحديث السيارة في فورم اخر في جدول الاسايند فييكلز ***


    ?>
     <select style="color:gray;" name="vehicleid"  >
     <option  value="">id vehicle</option>
       <?php
// ذولا الي ليس اساين
       while($r =mysqli_fetch_array($s))
      { ?>
       <option value="<?php echo $r['id'];?>"       ><?php echo $r['id']." ".$r['vehiclename'];?></option> 
       
       <?php    
      }
*/
      ?>
       
       </select>

    <label style="color:#4c548c;">Admin ID</label>
     
        <input name="added_adminid" type="text" value="<?=$driver['added_adminid']; ?>">
        <!-- value="<?php // echo $_SESSION['id'];?>"  -->

        <input type="submit"  name="editDriver" value="Edit Driver">
    </form>

    <?php
    }
  } else {
      ?>
<div class="container"><center><h4>No record found</h4></center> </div>
<?php
      }
}
?>

  </div>


</body>

<?//=$driver['vehicleid'] == $r['id'] ? 'selected' : '' 
//     <?php/* $r =mysqli_fetch_array($s); */ ?>

?>

      <!-- if(!$con)
      {
echo"connection failed";

      }
      $query="select*from vehicle";
      $run=mysqli_query($con,$query);
     
       ?>
        <select  name="vehicleid"
      //
      //  while($row = $query-> fetch_assoc()){echo"<option value=".$row[id].">".$row[vehiclename]. "</option >";}
      // while($data = mysqli_fetch_array($run))
      //  {
      //  echo"<option value=".$data[0].$data[1].">".$data[0].$data[1]."</option>";
      //  }
        
      -->
</html>
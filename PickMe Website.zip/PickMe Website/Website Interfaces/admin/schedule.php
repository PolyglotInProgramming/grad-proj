<?php
  session_start();

  include 'connection.php';

if (isset($_POST['findDriver'])) {
/*
  $triptype = $_POST['triptype'];
  $city = $_POST['city'];
  $category = $_POST['category'];
*/
$_SESSION["city"] =$_POST['city'];
$_SESSION["triptype"] = $_POST['triptype'];
$_SESSION["category"] =$_POST['category'];
  //
  if($_SESSION["triptype"]=="null" || $_SESSION["city"]=="null" || $_SESSION["category"]=="null" ){
      $_SESSION["findDriverStatus"] = "The * fields are required to suggest suitable drivers";
      header("Location:add_schedule_findD.php");
  } else {
    header("Location:add_schedule_create.php");
  }
  
}//end of big if  
?>



<?php
  include 'connection.php';
// go back 
  if (isset($_POST['Back'])) {
    header("Location:add_schedule_findD.php");
}
//\\//
// continue 
if (isset($_POST['addSchedule'])) {
/*
    $triptype = $_POST['triptype'];
    $city = $_POST['city'];
    $category = $_POST['category'];
*/

    $added_adminid = $_POST['added_adminid'];
    $driverid = $_POST['driverid'];
    $date = $_POST['date'];
    $pickuptime = $_POST['pickuptime'];
    $dropofftime = $_POST['dropofftime'];
    
    // xx--xx checking the DATE

      


    //checking the time
    //\\//\\اجرب بتوين//\\مايشيك\\//\\//\\// 
    $select1 ="SELECT driverid, date,pickuptime, dropofftime FROM reservation where (driverid='$driverid' AND date='$date') AND pickuptime='$pickuptime' AND dropofftime='$dropofftime'";
    $select2 ="SELECT driverid, date,pickuptime, dropofftime FROM reservation where (driverid='$driverid' AND date='$date') AND pickuptime BETWEEN '$pickuptime' AND '$dropofftime'";
    $result1 = mysqli_query($conn, $select1);
    $result2 = mysqli_query($conn, $select2);
// check if date in the future or not

   
$todydate = date('Y-m-d');
// convert to strotime
$str_res = strtotime($date); 
$str_todydate = strtotime($todydate); 
// compare
if($str_res < $str_todydate){
  $_SESSION['reservationDate'] ="The date cannot be in the past";
  header("Location:add_schedule_create.php");
}else {




 if (mysqli_num_rows($result1) || mysqli_num_rows($result2) > 0 ){
    $_SESSION["addScheduleStatus"] = "Driver already assigned to schedule at the specified time";
    header("Location:add_schedule_create.php");

    }elseif($driverid =='null'){
        $_SESSION["addScheduleStatus"] = "Choose Driver";
        header("Location:add_schedule_create.php");    
    }else{

// price
//      $price = $_POST['price'];
      
        if($_SESSION["triptype"]=="Long" AND $_SESSION["category"]=="First class"){
          $price = 500;
        }elseif($_SESSION["triptype"]=="Short" AND $_SESSION["category"]=="First class"){
          $price = 250;          
        }elseif($_SESSION["triptype"]=="Long" AND $_SESSION["category"]=="express"){
          $price = 250;          
        }elseif($_SESSION["triptype"]=="Short" AND $_SESSION["category"]=="express"){
          $price = 125;
        }elseif($_SESSION["triptype"]=="Long" AND $_SESSION["category"]=="Standard"){
          $price = 150;          
        }elseif($_SESSION["triptype"]=="Short" AND $_SESSION["category"]=="Standard"){
          $price = 75;
        }elseif($_SESSION["triptype"]=="Long" AND $_SESSION["category"]=="Delivery vans"){
          $price = 100;
        }
        elseif($_SESSION["triptype"]=="Short" AND $_SESSION["category"]=="Delivery vans"){
          $price = 50;          
        }
   
    //insert in the database
    $s=mysqli_query($conn,"INSERT INTO reservation (added_adminid, driverid, date, pickuptime, dropofftime,price)  VALUES ('$added_adminid','$driverid','$date','$pickuptime','$dropofftime','$price')");
    $_SESSION["addScheduleStatus"] = "Schedule added successfully";
    header("Location:add_schedule_findD.php");
    } //end of if else in the big if else
  }}

//end of big if }


//\\//
// delete schedule
if (isset($_POST['deleteSch'])) {

      $status = $_POST['status'];
      $R_id= $_POST['deleteSch'];

 if ($status  == 'available'){ 
  //delete 
  $q = "DELETE FROM reservation WHERE Rid='$R_id'";
  $d = mysqli_query($conn,$q);
    //
 
        $_SESSION["deleteSchedule"] = "The Schedule deleted successfully";
        header("Location:organize_schedule.php");
    }else { 
    //realy reserved
    $_SESSION["deleteSchedule"] = "Cannot delete Schedule under progrsess";
    header("Location:organize_schedule.php");
  }}
  //end of big if  
?>



<?php
//\\// view details
if(isset($_POST['checking_viewbtn']))
{
  
  $r_id = $_POST['reservation_id'];
  //echo $retern= $r_id ;

  $sql ="SELECT *  from reservation_view WHERE Rid='$r_id'";
$result = $conn-> query($sql);

if ($result-> num_rows > 0)
{
    foreach ( $result as $row)
    {
      echo $retern= '<h6> Customer id: '.$row["Cid"].'</h6>'
      .'<h6> Customer name: '.$row["customernamef"].' '.$row["customernamel"].'</h6>'
      .'<h6> Customer phone: '. $row["customerno"] .'</h6>'
      . '<hr>'. '<h6> Driver id: '.$row["Did"].'</h6>'
      .'<h6> Driver name: '.$row["drivernamef"].' '.$row["drivernamel"].'</h6>'
      .'<h6> Driver phone: '. $row["driverno"] .'</h6>'
      . '<hr>'. '<h6> Vehicle id: '.$row["vid"].'</h6>'
      .'<h6> Vehicle name: '.$row["vehiclename"].'</h6>';
    }
}else{
echo $retern= "<h5>No Record Found</h5>";
}




}

?>



















<?php
/*
    if(mysqli_num_rows($s) == 0) {
    echo '<option value=""> No suitable drivers </option>'; 
    }elseif(mysqli_num_rows($s) > 0){
    echo '<option value="">id driver</option>';  
    } 
*/


/*
if (isset($_GET['findDriver'])) {
    $triptype = $_GET['triptype'];
    $city = $_GET['city'];
    $category = $_GET['category'];

    //$con = mysqli_connect('localhost','root','','pickme');
    $s=mysqli_query($conn,"SELECT id, fname FROM suitable_drivers WHERE city ='$city' AND triptype='$triptype' AND category='$category'");
    $r = mysqli_fetch_array($s);
    header("Location:add_schedule.php");

    }
    */
?> 



<?php 
/*
<select style="color:gray;" name="driverid" required>
    <option  value="">id driver</option>
    <?php
    while($r)
   { ?>
    <option value="<?php echo $r['id'];?>"> <?php echo $r['id']." ".$r['fname'];?> </option> 
    <?php    
   }
   ?>
    </select>
*/ 
?>

<?php
  session_start();
  include 'connection.php';
  if (isset($_POST['submit'])) {
    $adminid=$_POST['added_adminid'];
  $date = date('Y-m-d');
    $text=$_POST['text'];
   
  }
   $insert = "INSERT INTO announcement (adminid,date, text) VALUES ('$adminid','$date','$text')";
    $result = mysqli_query($conn,$insert);
   $_SESSION['announcStatus'] = "Annoucement sent successfully.";
    header("Location:admin_send_annunc.php");

/*else {
    $_SESSION['announcStatus'] = "Try again";
    header("Location:add_vehicle.php");
    
    if (mysqli_num($result) > 0) {
    $_SESSION['regesterStatus'] = "Annoucement sent successfully.";
    header("Location:add_vehicle.php");
   } else {
    $_SESSION['regesterStatus'] = "Vehicle added successfully";
    $registr = "INSERT INTO vehicle (vehiclename, category, vehicleplate, vehicleyear, added_adminid) VALUES ('$vehiclename', '$category', '$vehicleplate', '$vehicleyear', '$added_adminid')";
    mysqli_query($conn,$registr);
    //$_SESSION['regesterStatus'] = "Driver registered sucessfully.";
    header("Location:add_vehicle.php");
}
*/
  
?>


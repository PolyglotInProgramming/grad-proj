
<?php
session_start();
include('connection.php');
if (isset($_POST['submit'])) {
    $vehiclename=$_POST['vehiclename'];
    $category=$_POST['category'];
    $vehicleplate=$_POST['vehicleplate'];
    $vehicleyear=$_POST['vehicleyear'];
    $added_adminid=$_POST['added_adminid'];

   $select = "SELECT * FROM vehicle WHERE vehicleplate = '$vehicleplate'";
    $result = mysqli_query($conn,$select);

    if (mysqli_num_rows($result) > 0) {
    $_SESSION['regesterStatus'] = "Vehicle plate already exists.";
    header("Location:add_vehicle.php");
   } else {
    $_SESSION['regesterStatus'] = "Vehicle added successfully";
    $registr = "INSERT INTO vehicle (vehiclename, category, vehicleplate, vehicleyear, added_adminid) VALUES ('$vehiclename', '$category', '$vehicleplate', '$vehicleyear', '$added_adminid')";
    mysqli_query($conn,$registr);
    //$_SESSION['regesterStatus'] = "Driver registered sucessfully.";
    header("Location:add_vehicle.php");
}
  }
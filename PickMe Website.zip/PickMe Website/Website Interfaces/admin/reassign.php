<?php 
session_start();
include('connection.php');
/*

if (isset($_POST['reassign'])) {

$driver_id=$_POST['driver_id'];
$vehicleid=$_POST['result'];


   
$update = "UPDATE driver SET vehicleid='$vehicleid' WHERE id='$driver_id'";
mysqli_query($conn,$update);
if($udate_run){
$_SESSION['reassign'] = "Vehicle reassigned successfully";

header("Location:Reassign_vehicle.php");      
}else{

  $_SESSION['reassign'] = "something went wrong";
  header("Location:Reassign_vehicle.php");      
}}

?>*/
if (isset($_POST['reassign'])) {

$driver_id= $_POST['driverid'];
//$Pvehicleid=$_POST['PsatVehicleid'];
$Nvehicleid=$_POST['NewVehicleid'];

//vname='$Pvehicleid' AND
$select = "SELECT * FROM reservation_details WHERE  driverid='$driver_id' AND NOT status = 'available'";
$check = mysqli_query($conn,$select);

if(mysqli_num_rows($check) >0){

  $_SESSION['reassignStatus'] = "The chosen driver has bookings based on his current vehicle. You cannot change it unless he finishes those bookings.";
  header("Location:assigned_vehicles.php");//<----      <----

}else{

  //   update     
  $update = "UPDATE driver SET  vehicleid='$Nvehicleid' WHERE id='$driver_id'";
  $Q = mysqli_query($conn,$update);

  if($Q){
    $_SESSION['reassignStatus'] = "Vehicle reassigned successfully";
    header("Location:assigned_vehicles.php");//<----      <----
  }
  /* else {
    $_SESSION['reassignStatus'] = "sql error";
    header("Location:assigned_vehicles.php");//<----      <----
  }*/

}







}

?>







<?php
  //echo $driver_id;
  //echo $vehicleid;
/*
$select = "SELECT * FROM driver WHERE email = '$email'";//AND id ='$id' ?
$result = mysqli_query($conn,$select);
*/
?>
<?php
  session_start();
  include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>DASHBOARD</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!--for icons-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    .navbar-nav>span {
      padding-left: 30px;
      padding-right: 0px;
    }

    .size {
      font-size: 100%;
      text-align: center;

    }

    .card {
      margin-bottom: 20px;
    }
  </style>
</head>

<body>
  <div class="container-fluid">
    <div style="background-color:#96A5D4;color:#ffffff;" class="row">
      <div class="col-1">
      </div>
      <div class="col">
        <br>
        <?php echo '<h5> Welcome <span class="text-warning">' . $_SESSION["fname"] .' '. $_SESSION["lname"]. ' </span>!</h5>';?>
      </div>
    </div>

    <div style="background-color:#4c548c;" class="row">
      <div class="col-1"></div>

      <div class="col">
      <nav style="background-color:#4c548c;" class="navbar navbar-expand-sm navbar-light size">
                    <a href="مها#"><img class="d-inline-block align-top" src="logo.png" width="60" height="60" /></a>
                    <div class="collapse.navbar-collapse" id="navbarNav" >
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a href="Dashboard.php" style="color:#d1d5e4" class="nav-link text-warning">
                                    DASHBOARD
                                </a>
                            </li>
                           
                            <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle " style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                  Manage Vehicles
                                </a>
                                <ul class="dropdown-menu "  >
                                  <li><a class="dropdown-item " style="color:#4c548c;" href="add_vehicle.php">Add Vehicle</a></li> 
                                  <li><a class="dropdown-item"  style="color:#4c548c;" href="vehicles_table.php">View Vehicles</a></li> 
                                  <li><a class="dropdown-item"  style="color:#4c548c;" href="assigned_vehicles.php">View assigned Vehicles</a></li> 
                                </ul>
                              </li>

                              <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle " style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Manage Drivers
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="add_driver.php">Add Driver</a></li> 
                                    <li><a class="dropdown-item"  style="color:#4c548c;" href="admin_view_driver.php">View Drivers</a></li> 
                                </ul>
                              </li>



                              <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle " style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Manage Reservations
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                <li><a class="dropdown-item " style="color:#4c548c;" href="add_schedule_findD.php">Organize Schedule</a></li> 
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="organize_schedule.php">Created Schedules</a></li> 
                                    <li><a class="dropdown-item "  style="color:#4c548c;" href="admin_view_reservations.php">View Reservations</a></li>                                </ul>
                              </li>  
                                                            

                              <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle " style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Customers
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="admin_view_customer.php">View Customers</a></li> 
                                    <li><a class="dropdown-item "  style="color:#4c548c;" href="admin_view_feedback.php">View Feedbacks</a></li>                                </ul>
                              </li>  

                            <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle " style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Announcements
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="admin_send_annunc.php	">Send Announcement</a></li> 
                                    <li><a class="dropdown-item"  style="color:#4c548c;" href="admin_annuncment.php">Sent Announcements</a></li> 
                                </ul>
                              </li> 


                            <span class="navbar-nav">
                                <button type="button" style="font-size: 100%;" class="btn btn-warning"> <a
                                        style="font-size: 100%;" class="btn p-0 " href="logout.php">Log Out</a>
                                </button>
                            </span>
                        </ul>
                    </div>
                </nav>
      </div>
      <div class="col-1"></div>

    </div>
  </div>

  <!--1-->
  <div class="container mt-3">
    <div class="row">
      <div class="col-md-3">
        <div class="card text-center">
          <div style="background-color:#96A5D4;" class="card-header text-white text-center">

            <div class="row align-items-center">
              <div class="col">
                <i class="fa fa-bus fa-3x"></i>
              </div>
              <div class="col">
                
                  <?PHP
                  $countv ="SELECT * FROM vehicle";
                  $run_count_v = mysqli_query($conn,$countv);
                 if($vehicle_total = mysqli_num_rows($run_count_v)){
                echo '<h3 class="display-5">'.$vehicle_total.'</h3>';

                 }else{
                  echo '<h4> no data</h4>';
                 }


                  ?>
                </h3>
                <h4>Vehicles </h4>
              </div>
            </div>
          </div>
          <div class="card-footer">
            <h6><a href="vehicles_table.php" style="text-decoration: none;">View details <i class="fa fa-arrow-circle-right"></i></a>
            </h6>

          </div>
        </div>
      </div>

      <!--2-->
      <div class="col-md-3">
        <div class="card text-center">
         
          <div style="background-color:#96A5D4;" class="card-header text-white text-center">

            <div class="row align-items-center">
              <div class="col">
                <i class="fa fa-bus fa-3x"></i>
              </div>
              <div class="col">
                
                  <?PHP
                  $countuv ="SELECT vehicle.id, vehicle.vehiclename FROM vehicle WHERE NOT EXISTS ( SELECT vehicleid FROM driver WHERE driver.vehicleid =vehicle.id )";
                  $run_count_uv = mysqli_query($conn,$countuv);
                 if($vehicle_total = mysqli_num_rows($run_count_uv)){
                echo '<h3 class="display-5">'.$vehicle_total.'</h3>';

                 }else{
                  echo '<h4> no data</h4>';
                 }


                  ?>
                </h3>
                <h5>Unassigned Vehicles </h5>
              </div>
            </div>
          </div>
          <div class="card-footer">
            <h6><a href="unassigned_vtable.php" style="text-decoration: none;">View details <i class="fa fa-arrow-circle-right"></i></a>
            </h6>

          </div>
        </div>
      </div>

      <!---->
      <div class="col-md-3">
        <div class="card text-center">
          <div style="background-color:#96A5D4;" class="card-header text-white text-center">

            <div class="row align-items-center">
              <div class="col">
                <i class="fa fa-id-card fa-3x"></i>
              </div>
              <div class="col">
              <?PHP
                  $countd ="SELECT * FROM driver";
                  $run_count_d = mysqli_query($conn,$countd);
                 if($driver_total = mysqli_num_rows($run_count_d)){
                echo '<h3 class="display-5">'.$driver_total.'</h3>';

                 }else{
                  echo '<h4> no data</h4>';
                 }


                  ?>
                <h4> Driveres</h4>
              </div>
            </div>
          </div>
          <div class="card-footer">
            <h6><a href="admin_view_driver.php" style="text-decoration: none;">View details <i class="fa fa-arrow-circle-right"></i></a>
            </h6>

          </div>
        </div>
      </div>
      <!--3-->

      <div class="col-md-3">
        <div class="card text-center">
          <div style="background-color:#96A5D4;" class="card-header text-white text-center">

            <div class="row align-items-center">
              <div class="col">
                <i class="fa fa-group fa-3x"></i>
              </div>
              <div class="col">
              <?PHP
                  $countc ="SELECT * FROM customer";
                  $run_count_c = mysqli_query($conn,$countc);
                 if($customer_total = mysqli_num_rows($run_count_c)){
                echo '<h3 class="display-5">'.$customer_total.'</h3>';

                 }else{
                  echo '<h4> no data</h4>';
                 }


                  ?>
                <h5>Registered Customers</h5>
              </div>
            </div>
          </div>
          <div class="card-footer">
            <h6><a href="admin_view_customer.php" style="text-decoration: none;">View details <i class="fa fa-arrow-circle-right"></i></a>
            </h6>
          </div>
        </div>
      </div>
      <!--4-->

      <div class="col-md-3">
        <div class="card text-center">
          <div style="background-color:#96A5D4;" class="card-header text-white text-center">

            <div class="row align-items-center">
              <div class="col">
                <i class="fa fa-bookmark fa-3x"></i>
              </div>
              <div class="col">
              <?PHP
                  $countr ="SELECT * FROM reservation WHERE NOT status='available' ";
                  $run_count_r = mysqli_query($conn,$countr);
                 if($reservation_total = mysqli_num_rows($run_count_r)){
                echo '<h3 class="display-5">'.$reservation_total.'</h3>';

                 }else{
                  echo '<h4> no data</h4>';
                 }


                  ?><br>
                <h5>Reservations</h5><br>
              </div>
            </div>
          </div>
          <div class="card-footer">
            <h6><a href="admin_view_reservations.php" style="text-decoration: none;">View details <i class="fa fa-arrow-circle-right"></i></a>
            </h6>
          </div>
        </div>
      </div>
      <!--5-->

      <div class="col-md-3">
        <div class="card text-center">
          <div style="background-color:#96A5D4;" class="card-header text-white text-center">

            <div class="row align-items-center">
              <div class="col">
                <i class="fa fa-history fa-3x"></i>
              </div>
              <div class="col">
              <h3 class="display-5">
              <?PHP
                  $countpv ="SELECT * FROM reservation WHERE status='pending'";
                  $run_count_pv = mysqli_query($conn,$countpv);
                 if($reservation_total = mysqli_num_rows($run_count_pv)){
                echo '<h3 class="display-5">'.$reservation_total.'</h3>';

                 }else{
                  echo '<h4> no data</h4>';
                 }


                  ?>
                  
                <h6>Pending Reservations</h6>
              </div>
            </div>
          </div>
          <div class="card-footer">
            <h6><a href="pendingres.php" style="text-decoration: none;">View details <i class="fa fa-arrow-circle-right"></i></a>
            </h6>
          </div>
        </div>
      </div>
      <!--6-->

      <div class="col-md-3">
        <div class="card text-center">
          <div style="background-color:#96A5D4;" class="card-header text-white text-center">

            <div class="row align-items-center">
              <div class="col">
                <i class="fa fa-remove fa-3x"></i>
              </div>
              <div class="col">
                <h3 class="display-5">
                <?PHP
                  $countpv ="SELECT * FROM reservation WHERE status='canceled'";
                  $run_count_pv = mysqli_query($conn,$countpv);
                 if($reservation_total = mysqli_num_rows($run_count_pv)){
                echo '<h3 class="display-5">'.$reservation_total.'</h3>';

                 }else{
                  echo '<h4> no data</h4>';
                 }


                  ?>
                <h6>Canceled Reservations</h6>
              </div>
            </div>
          </div>
          <div class="card-footer">
            <h6><a href="canceled_details.php" style="text-decoration: none;">View details <i class="fa fa-arrow-circle-right"></i></a>
            </h6>
          </div>
        </div>
      </div>
      <!--7-->

      <div class="col-md-3">
        <div class="card text-center">
          <div style="background-color:#96A5D4;" class="card-header text-white text-center">

            <div class="row align-items-center">
              <div class="col">
                <i class="fa fa-road fa-3x"></i>
              </div>
              <div class="col">
                <h3 class="display-5">
                <?PHP
                  $countpv ="SELECT * FROM reservation WHERE status='picked up'";
                  $run_count_pv = mysqli_query($conn,$countpv);
                 if($reservation_total = mysqli_num_rows($run_count_pv)){
                echo '<h3 class="display-5">'.$reservation_total.'</h3>';

                 }else{
                  echo '<h4> no data</h4>';
                 }


                  ?>
                <h6>Picked up Reservations</h6>
              </div>
            </div>
          </div>
          <div class="card-footer">
            <h6><a href="pickedup_res.php" style="text-decoration: none;">View details <i class="fa fa-arrow-circle-right"></i></a>
            </h6>
          </div>
        </div>
      </div>
      <!--8-->

      <div class="col-md-3">
        <div class="card text-center">
          <div style="background-color:#96A5D4;" class="card-header text-white text-center">

            <div class="row align-items-center">
              <div class="col">
                <i class="fa fa-check fa-3x"></i>
              </div>
              <div class="col">
                <h3 class="display-5">
                <?PHP
                  $countpv ="SELECT * FROM reservation WHERE status='dropped off'";
                  $run_count_pv = mysqli_query($conn,$countpv);
                 if($reservation_total = mysqli_num_rows($run_count_pv)){
                echo '<h3 class="display-5">'.$reservation_total.'</h3>';

                 }else{
                  echo '<h4> no data</h4>';
                 }


                  ?>
                <h6>Dropped Off Reservations</h6>
              </div>
            </div>
          </div>
          <div class="card-footer">
            <h6><a href="droppedoff.php" style="text-decoration: none;">View details <i class="fa fa-arrow-circle-right"></i></a>
            </h6>
          </div>
        </div>
      </div>
      <!--9-->
  <div class="col-md-3">
        <div class="card text-center">
          <div style="background-color:#96A5D4;" class="card-header text-white text-center">

            <div class="row align-items-center">
              <div class="col">
                <i class="fa fa-credit-card fa-3x"></i>
              </div>
              <div class="col">
              <h3 class="display-5">
              <?PHP
                  $countpv ="SELECT * FROM reservation WHERE status='paid'";
                  $run_count_pv = mysqli_query($conn,$countpv);
                 if($reservation_total = mysqli_num_rows($run_count_pv)){
                echo '<h3 class="display-5">'.$reservation_total.'</h3>';

                 }else{
                  echo '<h4> no data</h4>';
                 }


                  ?>
                  
                <h6>Paid Reservations</h6>
              </div>
            </div>
          </div>
          <div class="card-footer">
            <h6><a href="paid_res.php" style="text-decoration: none;">View details <i class="fa fa-arrow-circle-right"></i></a>
            </h6>
          </div>
        </div>
      </div>

</body>

</html>
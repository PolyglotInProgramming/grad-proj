<?php
  session_start();
  include 'connection.php';

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password=md5($password);
  $_SESSION["email"] = $result['email'];
    $select = "SELECT * FROM admin WHERE email = '$email' AND password = '$password'";
    $result = mysqli_query($conn, $select);
    if (mysqli_num_rows($result) == 1 ) {
        $result = mysqli_fetch_array($result);
        $_SESSION["email"] = $result['email'];
        $_SESSION["password"] = $result['password'];
        $_SESSION["fname"] = $result['fname'];
        $_SESSION["lname"] = $result['lname'];
        $_SESSION["id"] = $result['id'];
        header("Location:Dashboard.php");
    } else {
        $_SESSION['loginStatus'] = "Invalid Email or Password!";
        header("Location:admin_login.php");
    }

  }

?>
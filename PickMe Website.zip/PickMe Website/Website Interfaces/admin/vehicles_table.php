<?php
  session_start();
  include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>View Vehicles</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!--for icons-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>


  <style>
    .navbar-nav>span {
      padding-left: 30px;
      padding-right: 0px;
    }

    .size {
      font-size: 100%;
      text-align: center;

    }

    i {
      color: #4c548c;
    }

    i:hover {
      color: #f1c232;
    }

    .card {
      margin-bottom: 20px;
    }

    .bttn {
      width: 25%;

      background-color: #4c548c;
      color: #f1c232;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    .content-table {
      border-collapse: collapse;
      margin: 25px 0;
      font-size: 0.9em;
      min-width: 400px;
      border-radius: 5px 5px 0 0;
      overflow: hidden;
    }

    .content-table thead tr {
      background-color: #4c548c;
      color: #f1c232;
      text-align: left;
      font-family: sans-serif;
      font-weight: bold;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
    }

    .content-table td {
      padding: 12px 15px;

    }

    .content-table tbody tr:nth-of-type(odd) {
      background-color: #D1E3FA;
    }

    a {

      text-decoration: nodec;
    }
  </style>
</head>

<body>
  <div class="container-fluid">
    <div style="background-color:#96A5D4;color:#ffffff;" class="row">
      <div class="col-1">
      </div>
      <div class="col">
        <br>
         <?php echo '<h5> Welcome <span class="text-warning">' . $_SESSION["fname"] .' '. $_SESSION["lname"].' </span>'.'!</h5>';?>
      </div>
    </div>
  </div>

  <div style="background-color:#4c548c;" class="row">
    <div class="col-1"></div>

    <div class="col">
    <nav style="background-color:#4c548c;" class="navbar navbar-expand-sm navbar-light size">
                    <a href="مها#"><img class="d-inline-block align-top" src="logo.png" width="60" height="60" /></a>
                    <div class="collapse.navbar-collapse" id="navbarNav" >
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a href="Dashboard.php" class="nav-link " style="color:#d1d5e4">
                                    DASHBOARD
                                </a>
                            </li>
                           
                            <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle  text-warning" style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                  Manage Vehicles
                                </a>
                                <ul class="dropdown-menu "  >
                                  <li><a class="dropdown-item " style="color:#4c548c;" href="add_vehicle.php">Add Vehicle</a></li> 
                                  <li><a class="dropdown-item bg-warning"  style="color:#4c548c;" href="vehicles_table.php">View Vehicles</a></li> 
                                  <li><a class="dropdown-item"  style="color:#4c548c;" href="assigned_vehicles.php">View assigned Vehicles</a></li> 
                                </ul>
                              </li>

                              <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle " style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Manage Drivers
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="add_driver.php">Add Driver</a></li> 
                                    <li><a class="dropdown-item"  style="color:#4c548c;" href="admin_view_driver.php">View Drivers</a></li> 
                                </ul>
                              </li>



                              <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle " style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Manage Reservations
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                <li><a class="dropdown-item " style="color:#4c548c;" href="add_schedule_findD.php">Organize Schedule</a></li> 
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="organize_schedule.php">Created Schedules</a></li> 
                                    <li><a class="dropdown-item "  style="color:#4c548c;" href="admin_view_reservations.php">View Reservations</a></li>
                                </ul>
                              </li>  
                                                            

                              <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle" style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Customers
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="admin_view_customer.php">View Customers</a></li> 
                                    <li><a class="dropdown-item " style="color:#4c548c;"  href="admin_view_feedback.php">View Feedbacks</a></li>                                </ul>
                              </li> 

                            <li class="nav-item dropdown ">
                                <a class="nav-link dropdown-toggle " style="color:#d1d5e4" herf="" data-bs-toggle="dropdown" >
                                    Announcements
                                </a>
                                <ul class="dropdown-menu" style="color:#d1d5e4" >
                                    <li><a class="dropdown-item " style="color:#4c548c;" href="admin_send_annunc.php	">Send Announcement</a></li> 
                                    <li><a class="dropdown-item"  style="color:#4c548c;" href="admin_annuncment.php">Sent Announcements</a></li> 
                                </ul>
                              </li> 


                            <span class="navbar-nav">
                                <button type="button" style="font-size: 100%;" class="btn btn-warning"> <a
                                        style="font-size: 100%;" class="btn p-0 " href="logout.php">Log Out</a>
                                </button>
                            </span>
                        </ul>
                    </div>
                </nav>
    </div>
  </div>
  <!----------------------->
  <br>

  <div class="container">
    <div class="row">
      <div class="col">

       

        <a href="add_vehicle.php"><button class="bttn">Add Vehicles</button></a>
      </div>
    </div>
  </div>
  <hr size=6% height=3px border-width=22 color="blue" />

  <div class="container">

  <div class="table-responsive">
     <table class="table table-hover">

    <table class="table table-striped content-table" style="width:100%">
      <thead>
        <tr>
          <th class="text-center">ID</th>
          <th class="text-left">Vehicle Name</th>
          <th class="text-left">Vehicle Plate</th>
          <th class="text-left">Category</th>
          <th class="text-left">Vehicle Year</th>
        </tr>
      </thead>

      <tbody>


        <tr>
  
        <?php
$conn = mysqli_connect("localhost","root","","pickme");
if($conn-> connect_error){
die("Connection failed:".$conn-> connect_error);
}
$sql ="SELECT id, vehiclename, vehicleplate, category, vehicleyear from vehicle";
$result = $conn-> query($sql);

if ($result-> num_rows > 0){
    while ($row = $result-> fetch_assoc()){
echo "<tr><td>".$row["id"]."</td><td>".$row["vehiclename"]."</td><td>".$row["vehicleplate"]."</td><td>".$row["category"]."</td><td>".$row["vehicleyear"]."</td></tr>";
    }
   
    echo "</table>";
}else{
    echo "0 result";
}
$conn-> close();

?>
      </tbody>
    </table>
    </table>

    </div>

    </div>




</body>

</html>
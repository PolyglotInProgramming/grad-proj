<?php
session_start();
include 'connection.php';


// send reset email
if(isset($_POST['resetLink'])){
    $email = $_POST['email'];


    $select = "SELECT * FROM admin WHERE email = '$email'";
    $result = mysqli_query($conn,$select);

    if (mysqli_num_rows($result) > 0) {

      require_once 'PHPMailer/mail.php';
        $user = $result->fetch_object();

        $mail->addAddress($_POST['email']);
        $mail->Subject="Reset password link";
        $mail->Body='<h5>Thank you </h5>'.'Here is your Reset password link' . '<br>'
        . '<a href="http://localhost/PickMe Website/Website Interfaces/admin/reset_form.php?email='. $_POST['email'] . ' &id='. $user->id 
        .'"> http://localhost/PickMe Website/Website Interfaces/admin/reset_form.php?email='. $_POST['email'] . ' &id='. $user->id .' </a>' ;
        
        $mail->setFrom('pickme@outlook.sa', 'Pick Me');
        $mail->send();
        

    $_SESSION['resetPassStatus'] = "Reset password link sent to your email";
    header("Location:admin_login.php");
   } else {

    $_SESSION['resetPassStatus'] = "This email is not registered.";
    header("Location:admin_login.php");

  }
}


//------------------------------------------------------------------------------------------
// reset password
if(isset($_POST['resetPass'])){
    $email = $_POST['email'];
    $id = $_POST['id'];
    $password = $_POST['password'];



    $hashed_password=md5($password);
    $reset = "UPDATE admin SET password = '$hashed_password' WHERE email = '$email'";
    $Q = mysqli_query($conn,$reset);
    $_SESSION['resetPassStatus'] = "Passwerd reseted sucessfully.";
    header("Location:admin_login.php");

   

}
//=======================================

/* قبل التعديل
// send reset email
if(isset($_POST['resetLink'])){
  $email = $_POST['email'];


  $select = "SELECT * FROM customer WHERE email = '$email'";
  $result = mysqli_query($conn,$select);

  if (mysqli_num_rows($result) > 0) {

    require_once 'PHPMailer/mail.php';
      $user = $result->fetch_object();

      $mail->addAddress($_POST['email']);
      $mail->Subject="Reset password link";
echo        $mail->Body='<h5>Thank you </h5>'.'Here is your Reset password link' . '<br>'
      . '<a href="http://localhost/form/email_to_send_resetLink.php?email='. $_POST['email'] . ' &id='. $user->id 
      .'"> http://localhost/form/reset_form.php?email='. $_POST['email'] . ' &id='. $user->id .' </a>' ;
      
      $mail->setFrom('pickme@outlook.sa', 'Pick Me');
      $mail->send();


  $_SESSION['resetPassStatus'] = "Reset password link sent to your email";
  header("Location:email_to_send_resetLink.php");
 } else {

  $_SESSION['resetPassStatus'] = "This email is not registered.";
  header("Location:  ");

}
}
*/



?>
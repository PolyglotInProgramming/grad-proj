<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-5">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <title>Home</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"></head>
        <style>

            .navbar-nav>span {
        
              padding-left: 40px;
        
              padding-right: 0px;
        
            }
        
        
        
            .size {
        
              font-size: 100%;
        
              text-align: center;
              
            }
          .navbar-nav>span {
      padding-left: 40px;
      padding-right: 0px;
    }



    .card {
      margin-bottom: 20px;
    }
        
        
        
        
          </style>
        
        </head>
        
        
        
        <body>
        
          <div class="container-fluid">
        
            <div style="background-color:#96A5D4;color:#ffffff;" class="row">
        
              <div class="col-1">
        
              </div>
        
                <div class="col">
        
                <br>
        
                
        
                </div>
        
            </div>
        
        
        
            <div style="background-color:#4c548c;" class="row">
        
              <div class="col-1"></div>
        
        
        
              <div class="col">
        
                <nav style="background-color:#4c548c;" class="navbar navbar-expand-sm navbar-light size">
        
                  <a href="#">
        
                    <class="navbar-brand mb-0 h1">
        
        
        
                      <img class="d-inline-block align-top" src="logo.png" width="60" height="60" />
        
                      <div class="collapse.navbar-collapse" id="navbarNav">
        
                        <ul class="navbar-nav">
        
                          <li class="nav-item">
        
                            <a href="Home.php" class="nav-link text-warning">
        
                              Home
        
                            </a>
        
                          </li>
        
                          <li class="nav-item">
        
                            <a href="About us.html" class="nav-link" style="color:#d1d5e4">About us</a>

        
                          </li>
        
                          <li class="nav-item">
        
                            <a href="Reserve.html" class="nav-link" style="color:#d1d5e4">Reserve</a>
        
                          </li>
        
                          <li class="nav-item">
        
                            <a href="Services.html" class="nav-link" style="color:#d1d5e4">Services</a>
        
                          </li>
        
                          <li class="nav-item">
        
                            <a href="FAQ.html" class="nav-link" style="color:#d1d5e4">FAQ</a>
        
                          </li>
        
                          <li class="nav-item">
        
                            <a href="Contacts.html" class="nav-link" style="color:#d1d5e4">Contacts</a>
        
                          </li>
        
                          <li class="nav-item">
        
                            <a href="Login.html" class="nav-link" style="color:#d1d5e4">Log in</a>
  
                          </li>
        
                          <li class="nav-item">
        
                         
        
                          </li>
        
        
        
                          <span class="navbar-nav">
        
                            <button type="button" style="font-size: 100%;" class="btn btn-warning"><a
                              style="font-size: 100%; color:black;"  href="customer/Registration.php">Sign up</a></button>
        
                          </span>
        
                        </ul>
        
                      </div>
        
                </nav>
        
              </div>
        
              <div class="col-1"></div>
        
        
        
            </div>
        
          </div>
    
          <div class="jumbotron">
          <div class="container">

            <h1 class="display-4">Hello!</h1>
            <p class="lead"><b><h2>Welcome to Pick Me website....</h2></b></p>
            </div>

            <hr class="my-4">
            <div id="carouselExampleInterval" class="carousel slide" data-ride="carousel">
              <div class="carousel-inner">
                <div class="carousel-item active" data-interval="10000">
                  <center><img src="go to.jpg"  alt="go to"  width="750" height="300"></center>
                </div>
                <div class="carousel-item" data-interval="2000">
                  <center><img src="location.jpg"  alt="location"  width="750" height="300"></center>
                </div>
                <div class="carousel-item">
                  <center><img src="reserve.jpg"  alt="reserve" width="750" height="300"></center>
                </div>
                <div class="carousel-item">
                  <center><img src="from airport.jpg"  alt="reserve" width="750" height="300"></center>
                </div>
                <div class="carousel-item">
                  <center><img src="logo2.jpg"  alt="reserve" width="750" height="300"></center>
                </div>
              </div>
              <a class="carousel-control-prev" href="#carouselExampleInterval" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
              </a>
              <a class="carousel-control-next" href="#carouselExampleInterval" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
              </a>
            </div>
          </div>
  
          <br>
     <!--     <center><h2><strong><p style="color: rgba(20, 0, 110, 0.726); font-family:courier;"></p>Add your feedback..</strong></h2></center>
          <br>

          <div class="input-group mb-3">
            <input type="text" class="form-control" placeholder="write here" aria-label="write here" aria-describedby="button-addon2">
            <div class="input-group-append">
              <button class="btn btn-outline-secondary" type="button" id="button-addon2">Ok</button>
            </div>
          </div>
          <br>
          <br>
          <br>-->


            
          </main>

    
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

<center>    
<div class="display-4" > Don't be late!</div><br><br>
     <h3>We are here for you so that you are not late for your flights. </h3><br>

     <h5>A company that has dedicated ourselves to transporting you to and from the airport. 
      <br><br> 
        Also here to serve you, we can transport your shipments.
     </h5>
</center>
<br>
    <body>
    <br><br>
    <div class="container-fluid">
    <center><h2 class="color:#4c548c">✨Customers feedbacks✨</h2></center>
    <br>


    <?php
    $conn = mysqli_connect("localhost","root","","pickme");
    if($conn-> connect_error){
    die("Connection failed:".$conn-> connect_error);
    }
    $sql ="SELECT * FROM homefeedback";
    $result = $conn-> query($sql);?>
 
    <div class="row">
        <?php
    if ($result-> num_rows > 0){
?>

<!-- ============ -->     
  <!--
      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
      </ol>
      <div class="carousel-inner">   
    -->   
<!-- ============ -->   

      <?php
        while ($row = $result-> fetch_assoc()){
   ?>

<!--<div class="carousel-item active"> ============ -->   

      <div class="col-md-3">
        <div class="card text-center">
          <div style="background-color:#4c548c ;" class="card-header text-white text-center">

            <div class="row align-items-center">
              <div class="col">
              <h4><?php echo $row['fname'] ?> </h4> <h6>   <p><?php echo $row['email'] ?> </p></h6>
              </div>
              <div class="col">
            
     <hr class="bg-warning">
            
              </div>
            </div>     <br>
     <h5>   <p class= "color:#4c548c">Commented✉️: <?php echo $row['text'] ?></p><h5>  
          </div>
          <div class="card-footer">
            <h6><a href="vehicles_table.php" style="text-decoration: none;"> <?php echo $row['date'] ?></a>
            </h6>

          </div>
        </div>
      </div>


<!--</div> ============ -->   
          

      <?php 
      }

    }?>

<!-- ============ -->   
<!--
</div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
  -->
<!-- ============ -->   

  </div> 
  </div>
      <div>  


      <footer>

      <div class="alert alert-success" style="background-color:#96A5D4;" role="alert">
              <div class="navbar">
                <a style="color: #ffffff;" href="About us.html" >About us</a>
                <a style="color: #ffffff;" href="Reserve.html">Reserve</a>
                <a style="color: #ffffff;" href="Services.html">Services</a>
                <a style="color: #ffffff;" href="FAQ.html">FAQ</a>
                <a style="color: #ffffff;" href="Contacts.html">Contacts</a>

             

                <div class="card">
                  <br><center><img class="d-inline-block align-top" src="email.PNG" width="20" height="20" /></center>
                  <div class="card-body">
                    <h6 class="card-title"><b>Email:</b></h6>
                    <a href="mailto:pickme@outlook.sa">pickme@outlook.sa</a>
                  </div>
                </div>
                <div class="card">
                  <br><center><img class="d-inline-block align-top" src="snap.PNG" width="20" height="20" /></center>
                  <div class="card-body">
                    <h6 class="card-title"><b>Snapchat:</b></h6>
                    <p class="card-text">Pick_Me</p>
                  </div>
                </div>
                <div class="card">
                  <br><center><img class="d-inline-block align-top" src="insta.PNG" width="20" height="20" /></center>
                  <div class="card-body">
                    <h6 class="card-title"><b>Instagram:</b></h6>
                    <p class="card-text">Pick_Me</p>
                  </div>
                </div>
              </div>
              <center><h5><strong>  <p style=" font-family:courier;">All rights reserved.</p></strong></h5></center>
           
            </div>
    </footer>    



    </body>
</html>
